# Task Management System

A PostgreSQL database schema using Prisma for managing users and tasks.

## Database Schema

The database consists of eight main entities:

### User
- id (UUID, primary key)
- username (string, unique)
- email (string, unique)
- password (hashed string)
- role (enum: 'user' | 'admin')
- created_at (timestamp)
- updated_at (timestamp)

### Task
- id (UUID, primary key)
- title (string)
- description (text, optional)
- due_date (date, optional)
- status (enum: 'pending' | 'in_progress' | 'completed')
- priority (enum: 'low' | 'medium' | 'high')
- owner_id (foreign key → User.id)
- created_at (timestamp)
- updated_at (timestamp)
- deleted_at (timestamp, nullable) - For soft delete functionality

### SharedTask
- id (UUID, primary key)
- task_id (foreign key → Task.id)
- shared_with_id (foreign key → User.id)
- permission (enum: 'view' | 'edit')
- created_at (timestamp)

Key constraints:
- Unique constraint on (task_id, shared_with_id) prevents duplicate sharing
- Check constraint ensures task owner ≠ shared_with_id

### TaskComment
- id (UUID, primary key)
- task_id (foreign key → Task.id)
- author_id (foreign key → User.id)
- comment (text)
- created_at (timestamp)

Comments are indexed and ordered by created_at by default.

### Notification
- id (UUID, primary key)
- user_id (foreign key → User.id)
- task_id (foreign key → Task.id)
- message (text)
- is_read (boolean, default false)
- created_at (timestamp)

Notifications are indexed by user_id and is_read for efficient filtering.

### PasswordResetToken
- id (UUID, primary key)
- user_id (foreign key → User.id)
- token (string, unique)
- expires_at (timestamp)
- created_at (timestamp)

Tokens auto-expire based on the expires_at field with a database trigger that automatically cleans up expired tokens.

### Category
- id (UUID, primary key)
- name (string, unique)
- color (string, optional)

### TaskCategory
- id (UUID, primary key)
- task_id (foreign key → Task.id)
- category_id (foreign key → Category.id)

This is a many-to-many relationship that allows assigning multiple categories/tags to one task.

## Soft Delete Functionality

Tasks support soft delete functionality via the `deleted_at` field:
- When `deleted_at` is NULL, the task is considered active
- When `deleted_at` has a timestamp, the task is considered deleted but still exists in the database
- An `active_tasks` database view is available to easily query only non-deleted tasks
- An index on `deleted_at` improves query performance when filtering by deletion status

## Setup Instructions

1. **Install dependencies:**
   ```
   npm install
   ```

2. **Configure environment variables:**
   Create a `.env` file in the root directory with the following content:
   ```
   DATABASE_URL="postgresql://username:password@localhost:5432/task_management_db"
   ```
   Replace username, password, and other parameters as needed.

3. **Create the database:**
   Make sure PostgreSQL is installed and running, then create a new database:
   ```
   createdb task_management_db
   ```

4. **Run migrations:**
   ```
   npm run prisma:migrate
   ```

5. **Generate Prisma Client:**
   ```
   npm run prisma:generate
   ```

6. **Explore the database with Prisma Studio:**
   ```
   npm run prisma:studio
   ```

## Usage Examples

### Creating a new user:
```javascript
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function createUser() {
  const user = await prisma.user.create({
    data: {
      username: 'johndoe',
      email: 'john@example.com',
      password: 'hashedPassword', // In production, ensure this is properly hashed
      role: 'USER'
    }
  });
  console.log(user);
}
```

### Creating a new task:
```javascript
async function createTask(userId) {
  const task = await prisma.task.create({
    data: {
      title: 'Complete project',
      description: 'Finish the database schema implementation',
      dueDate: new Date('2023-12-31'),
      status: 'PENDING',
      priority: 'HIGH',
      ownerId: userId
    }
  });
  console.log(task);
}
```

### Soft-deleting a task:
```javascript
async function softDeleteTask(taskId) {
  const task = await prisma.task.update({
    where: { id: taskId },
    data: { deletedAt: new Date() }
  });
  console.log(`Task ${task.title} soft-deleted`);
}
```

### Restoring a soft-deleted task:
```javascript
async function restoreTask(taskId) {
  const task = await prisma.task.update({
    where: { id: taskId },
    data: { deletedAt: null }
  });
  console.log(`Task ${task.title} restored`);
}
```

### Getting active (non-deleted) tasks:
```javascript
async function getActiveTasks() {
  const tasks = await prisma.task.findMany({
    where: { deletedAt: null }
  });
  console.log(tasks);
}
```

### Getting deleted tasks:
```javascript
async function getDeletedTasks() {
  const tasks = await prisma.task.findMany({
    where: { deletedAt: { not: null } }
  });
  console.log(tasks);
}
```

### Creating a category:
```javascript
async function createCategory(name, color = null) {
  const category = await prisma.category.create({
    data: {
      name,
      color
    }
  });
  console.log(category);
}
```

### Assigning categories to a task:
```javascript
async function assignCategoryToTask(taskId, categoryId) {
  const taskCategory = await prisma.taskCategory.create({
    data: {
      taskId,
      categoryId
    }
  });
  console.log(taskCategory);
}
```

### Getting tasks by category:
```javascript
async function getTasksByCategory(categoryId) {
  const tasks = await prisma.taskCategory.findMany({
    where: {
      categoryId,
      task: {
        deletedAt: null // Only include non-deleted tasks
      }
    },
    include: {
      task: true
    }
  });
  
  return tasks.map(tc => tc.task);
}
```

### Getting categories for a task:
```javascript
async function getCategoriesForTask(taskId) {
  const taskWithCategories = await prisma.task.findUnique({
    where: {
      id: taskId
    },
    include: {
      categories: {
        include: {
          category: true
        }
      }
    }
  });
  
  return taskWithCategories.categories.map(tc => tc.category);
}
```

### Sharing a task with another user:
```javascript
async function shareTask(taskId, sharedWithUserId) {
  const sharedTask = await prisma.sharedTask.create({
    data: {
      taskId: taskId,
      sharedWithId: sharedWithUserId,
      permission: 'VIEW'  // or 'EDIT'
    }
  });
  console.log(sharedTask);
}
```

### Adding a comment to a task:
```javascript
async function addComment(taskId, authorId, commentText) {
  const comment = await prisma.taskComment.create({
    data: {
      taskId: taskId,
      authorId: authorId,
      comment: commentText
    }
  });
  console.log(comment);
}
```

### Creating a notification for upcoming due task:
```javascript
async function createNotification(userId, taskId) {
  const task = await prisma.task.findUnique({
    where: { id: taskId }
  });
  
  const notification = await prisma.notification.create({
    data: {
      userId: userId,
      taskId: taskId,
      message: `Task "${task.title}" is due soon!`
    }
  });
  console.log(notification);
}
```

### Creating a password reset token:
```javascript
async function createPasswordResetToken(userId) {
  // Generate a secure random token
  const crypto = require('crypto');
  const token = crypto.randomBytes(32).toString('hex');
  
  // Set expiration time (e.g., 1 hour from now)
  const expiresAt = new Date();
  expiresAt.setHours(expiresAt.getHours() + 1);
  
  const resetToken = await prisma.passwordResetToken.create({
    data: {
      userId: userId,
      token: token,
      expiresAt: expiresAt
    }
  });
  
  return resetToken.token;
}
```

### Validating a password reset token:
```javascript
async function validatePasswordResetToken(token) {
  const resetToken = await prisma.passwordResetToken.findFirst({
    where: {
      token: token,
      expiresAt: {
        gt: new Date() // Check if token hasn't expired
      }
    },
    include: {
      user: true // Include user details
    }
  });
  
  if (!resetToken) {
    throw new Error('Invalid or expired password reset token');
  }
  
  return resetToken.user;
}
```

### Getting unread notifications for a user:
```javascript
async function getUnreadNotifications(userId) {
  const notifications = await prisma.notification.findMany({
    where: { 
      userId: userId,
      isRead: false,
      task: {
        deletedAt: null // Only include notifications for non-deleted tasks
      }
    },
    include: {
      task: true
    },
    orderBy: {
      createdAt: 'desc'
    }
  });
  console.log(notifications);
}
```

### Getting a task with its comments:
```javascript
async function getTaskWithComments(taskId) {
  const task = await prisma.task.findUnique({
    where: { id: taskId },
    include: {
      owner: true,
      comments: {
        include: {
          author: true
        },
        orderBy: {
          createdAt: 'asc'  // Comments ordered by creation date
        }
      }
    }
  });
  console.log(task);
}
```

### Getting a task with its sharing information:
```javascript
async function getTaskWithSharing(taskId) {
  const task = await prisma.task.findUnique({
    where: { id: taskId },
    include: {
      owner: true,
      sharedWith: {
        include: {
          sharedWith: true
        }
      }
    }
  });
  console.log(task);
} 