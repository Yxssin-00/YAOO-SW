const express = require('express');
const router = express.Router();
const taskController = require('../controllers/taskController');
const { protect } = require('../middlewares/authMiddleware');

// Task CRUD operations
router.post('/', protect, taskController.createTask);
router.get('/', protect, taskController.getMyTasks);
router.put('/:id', protect, taskController.updateTask);
router.delete('/:id', protect, taskController.deleteTask);

// Task status update
router.patch('/:id/status', protect, taskController.updateTaskStatus);

module.exports = router;