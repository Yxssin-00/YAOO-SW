const pool = require('../config/db');

const createTask = async (userId, title, description, due_date, priority) => {
  const result = await pool.query(
    `INSERT INTO tasks (user_id, title, description, due_date, priority)
     VALUES ($1, $2, $3, $4, $5) RETURNING *`,
    [userId, title, description, due_date, priority]
  );
  return result.rows[0];
};

const getTasksByUser = async (userId) => {
  const result = await pool.query(
    'SELECT * FROM tasks WHERE user_id = $1 ORDER BY created_at DESC',
    [userId]
  );
  return result.rows;
};

const getTaskById = async (id) => {
  const result = await pool.query('SELECT * FROM tasks WHERE id = $1', [id]);
  return result.rows[0];
};

const updateTask = async (id, title, description, due_date, priority, status) => {
  // Build the update query dynamically based on provided fields
  let query = 'UPDATE tasks SET ';
  const params = [];
  const values = [];
  
  if (title) {
    params.push(`title = $${params.length + 1}`);
    values.push(title);
  }
  
  if (description !== undefined) {
    params.push(`description = $${params.length + 1}`);
    values.push(description);
  }
  
  if (due_date) {
    params.push(`due_date = $${params.length + 1}`);
    values.push(due_date);
  }
  
  if (priority) {
    params.push(`priority = $${params.length + 1}`);
    values.push(priority);
  }
  
  if (status) {
    params.push(`status = $${params.length + 1}`);
    values.push(status);
  }
  
  // Add updated_at timestamp
  params.push(`updated_at = $${params.length + 1}`);
  values.push(new Date());
  
  // Add WHERE clause
  query += params.join(', ') + ` WHERE id = $${values.length + 1} RETURNING *`;
  values.push(id);
  
  const result = await pool.query(query, values);
  return result.rows[0];
};

const updateTaskStatus = async (id, status) => {
  const result = await pool.query(
    `UPDATE tasks SET status = $1, updated_at = $2 WHERE id = $3 RETURNING *`,
    [status, new Date(), id]
  );
  return result.rows[0];
};

const deleteTask = async (id) => {
  await pool.query('DELETE FROM tasks WHERE id = $1', [id]);
};

module.exports = {
  createTask,
  getTasksByUser,
  getTaskById,
  updateTask,
  updateTaskStatus,
  deleteTask,
};