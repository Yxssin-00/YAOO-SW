# TaskMate - Task Management System

A full-stack task management application built with Node.js, Express, PostgreSQL, jQuery, and Bootstrap.

## Project Structure

The project consists of two main parts:

- **Frontend**: A jQuery and Bootstrap-based UI located in the `project_frontend (2)` directory
- **Backend**: A Node.js/Express API located in the `backend` directory

## Prerequisites

- Node.js (v14 or higher)
- PostgreSQL database
- npm or yarn

## Setup Instructions

### Backend Setup

1. Navigate to the backend directory:
   ```
   cd backend
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Configure the database:
   - Make sure PostgreSQL is running
   - Check the database configuration in `backend/config/db.js`
   - The default configuration is:
     ```
     host: 'localhost',
     port: 5432,
     user: 'postgres',
     password: '113355',
     database: 'new3.4'
     ```
   - Update these values if your PostgreSQL configuration is different

4. Start the backend server:
   ```
   npm start
   ```
   - The server will run on http://localhost:5000

### Frontend Setup

1. Navigate to the frontend directory:
   ```
   cd "project_frontend (2)"
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the frontend server:
   ```
   npm start
   ```
   - The frontend will be available at http://localhost:8084

## Using the Application

1. Open your browser and navigate to http://localhost:8084
2. Login with one of the demo accounts:
   - Regular user: john@example.com / password
   - Admin user: admin@example.com / password

## Features

- User authentication (login/register)
- Task management (create, edit, delete)
- Task filtering and sorting
- Task sharing with other users
- Task comments
- Calendar view
- User profile management
- Admin panel (for admin users)
- Dark mode toggle
- Responsive design

## Offline Mode

The application has a fallback mechanism that uses localStorage when the backend API is unavailable, allowing for a demo experience without a running backend.

## API Endpoints

### Authentication
- POST /api/auth/login
- POST /api/auth/register
- GET /api/auth/verify
- POST /api/auth/logout
- POST /api/auth/reset-password

### Tasks
- GET /api/task
- POST /api/task
- GET /api/task/:id
- PUT /api/task/:id
- DELETE /api/task/:id
- PATCH /api/task/:id/status
- POST /api/task/:id/share
- GET /api/task/:id/comments
- POST /api/task/:id/comments
- GET /api/task/notifications

### Users
- GET /api/user/:id
- PUT /api/user/:id
- POST /api/user/profile/update

### Admin
- GET /api/admin/users
- GET /api/admin/users/:id
- PUT /api/admin/users/:id
- DELETE /api/admin/users/:id
- PATCH /api/admin/users/:id/status 