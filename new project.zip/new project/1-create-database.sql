-- Create the database
CREATE DATABASE "new3.4"; 