/**
 * TaskMate - Task Management System
 * Admin Panel Functions
 */

// Load users for admin panel
function loadAdminUsers() {

console.log('Admin.js loaded successfully!');

    const userList = $('#user-list');
    
    // Show loading indicator
    userList.html(`
        <div class="text-center p-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading users...</p>
        </div>
    `);
    
    // API URL for admin users
    const apiUrl = 'http://localhost:5000/api/admin/users';
    
    // Use jQuery's AJAX to fetch users
    $.ajax({
        url: apiUrl,
        type: 'GET',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        success: function(response) {
            renderUserList(response);
        },
        error: function(xhr, status, error) {
            console.error('Error fetching users:', error);
            
            if (xhr.status === 401 || xhr.status === 403) {
                userList.html(`
                    <div class="alert alert-danger">
                        <h4 class="alert-heading">Access Denied</h4>
                        <p>You do not have permission to access the admin panel.</p>
                    </div>
                `);
            } else if (xhr.status === 0) {
                console.log('API server might be down, using mock data');
                // Use mock data if API is down
                const mockUsers = getMockUsers();
                renderUserList(mockUsers);
            } else {
                userList.html(`
                    <div class="alert alert-danger">
                        <h4 class="alert-heading">Error</h4>
                        <p>Failed to load users: ${error}</p>
                        <button class="btn btn-outline-danger btn-sm" onclick="loadAdminUsers()">Try Again</button>
                    </div>
                `);
            }
        }
    });
}

// Render user list in admin panel
function renderUserList(users) {
    const userList = $('#user-list');
    userList.empty();
    
    if (!users || users.length === 0) {
        userList.html(`
            <div class="alert alert-info">
                <p class="mb-0">No users found.</p>
            </div>
        `);
        return;
    }
    
    // Create table
    const table = $(`
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    `);
    
    const tbody = table.find('tbody');
    
    // Add users to table
    users.forEach(user => {
        const statusBadge = user.active ? 
            '<span class="badge bg-success">Active</span>' : 
            '<span class="badge bg-danger">Inactive</span>';
        
        const row = $(`
            <tr data-user-id="${user.id}">
                <td>${user.id}</td>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td><span class="badge ${user.role === 'admin' ? 'bg-primary' : 'bg-secondary'}">${user.role}</span></td>
                <td>${statusBadge}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-info view-user" title="View Profile">
                            <i class="fas fa-user"></i>
                        </button>
                        <button class="btn btn-outline-warning toggle-status" title="${user.active ? 'Deactivate' : 'Activate'}">
                            <i class="fas ${user.active ? 'fa-ban' : 'fa-check'}"></i>
                        </button>
                        <button class="btn btn-outline-danger delete-user" title="Delete User">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `);
        
        // Attach event listeners
        row.find('.view-user').on('click', function() {
            viewUserProfile(user.id);
        });
        
        row.find('.toggle-status').on('click', function() {
            toggleUserStatus(user.id, !user.active);
        });
        
        row.find('.delete-user').on('click', function() {
            confirmDeleteUser(user.id, user.name);
        });
        
        tbody.append(row);
    });
    
    userList.append(table);
    
    // Add search and filter controls
    const controls = $(`
        <div class="row mb-3">
            <div class="col-md-6">
                <div class="input-group">
                    <input type="text" class="form-control" id="user-search" placeholder="Search users...">
                    <button class="btn btn-outline-secondary" type="button" id="search-btn">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
            <div class="col-md-4">
                <select class="form-select" id="role-filter">
                    <option value="">All Roles</option>
                    <option value="admin">Admin</option>
                    <option value="user">User</option>
                </select>
            </div>
            <div class="col-md-2">
                <button class="btn btn-primary w-100" id="add-user-btn">
                    <i class="fas fa-plus"></i> Add User
                </button>
            </div>
        </div>
    `);
    
    // Add search functionality
    controls.find('#search-btn').on('click', function() {
        const searchTerm = $('#user-search').val().toLowerCase();
        filterUsers(searchTerm, $('#role-filter').val());
    });
    
    controls.find('#user-search').on('keyup', function(e) {
        if (e.key === 'Enter') {
            const searchTerm = $(this).val().toLowerCase();
            filterUsers(searchTerm, $('#role-filter').val());
        }
    });
    
    // Add role filter functionality
    controls.find('#role-filter').on('change', function() {
        const role = $(this).val();
        const searchTerm = $('#user-search').val().toLowerCase();
        filterUsers(searchTerm, role);
    });
    
    // Add user button
    controls.find('#add-user-btn').on('click', function() {
        showAddUserModal();
    });
    
    userList.prepend(controls);
}

// Filter users based on search term and role
function filterUsers(searchTerm, role) {
    const rows = $('#user-list tbody tr');
    
    rows.each(function() {
        const $row = $(this);
        const name = $row.find('td:nth-child(2)').text().toLowerCase();
        const email = $row.find('td:nth-child(3)').text().toLowerCase();
        const userRole = $row.find('td:nth-child(4)').text().toLowerCase();
        
        const nameMatch = name.includes(searchTerm);
        const emailMatch = email.includes(searchTerm);
        const roleMatch = role === '' || userRole === role;
        
        if ((nameMatch || emailMatch) && roleMatch) {
            $row.show();
        } else {
            $row.hide();
        }
    });
}

// View user profile
function viewUserProfile(userId) {
    console.log('Viewing user profile:', userId);
    
    // API URL
    const apiUrl = `http://localhost:5000/api/admin/users/${userId}`;
    
    // Show loading state
    $('#user-profile-container').html(`
        <div class="text-center p-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading user profile...</p>
        </div>
    `);
    
    // Use jQuery's AJAX to fetch user details
    $.ajax({
        url: apiUrl,
        type: 'GET',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        success: function(user) {
            showUserProfileModal(user);
        },
        error: function(xhr, status, error) {
            console.error('Error fetching user profile:', error);
            
            if (xhr.status === 0) {
                // API is down, use mock data
                const mockUsers = getMockUsers();
                const user = mockUsers.find(u => u.id === userId);
                if (user) {
                    showUserProfileModal(user);
                } else {
                    showToast('error', 'Error', 'User not found');
                }
            } else {
                showToast('error', 'Error', `Failed to load user profile: ${error}`);
            }
        }
    });
}

// Show user profile modal
function showUserProfileModal(user) {
    // Create modal if it doesn't exist
    if ($('#user-profile-modal').length === 0) {
        const modalHTML = `
            <div class="modal fade" id="user-profile-modal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">User Profile</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="text-center mb-3">
                                <div class="avatar-placeholder">
                                    <i class="fas fa-user fa-3x"></i>
                                </div>
                            </div>
                            <div class="user-details">
                                <!-- User details will be loaded here -->
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
    }
    
    // Update modal content
    const userDetails = $('#user-profile-modal .user-details');
    userDetails.html(`
        <div class="row mb-2">
            <div class="col-4 fw-bold">ID:</div>
            <div class="col-8">${user.id}</div>
        </div>
        <div class="row mb-2">
            <div class="col-4 fw-bold">Name:</div>
            <div class="col-8">${user.name}</div>
        </div>
        <div class="row mb-2">
            <div class="col-4 fw-bold">Email:</div>
            <div class="col-8">${user.email}</div>
        </div>
        <div class="row mb-2">
            <div class="col-4 fw-bold">Role:</div>
            <div class="col-8">
                <span class="badge ${user.role === 'admin' ? 'bg-primary' : 'bg-secondary'}">${user.role}</span>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-4 fw-bold">Status:</div>
            <div class="col-8">
                ${user.active ? 
                    '<span class="badge bg-success">Active</span>' : 
                    '<span class="badge bg-danger">Inactive</span>'}
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-4 fw-bold">Created:</div>
            <div class="col-8">${new Date(user.createdAt).toLocaleString()}</div>
        </div>
    `);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('user-profile-modal'));
    modal.show();
}

// Toggle user status (activate/deactivate)
function toggleUserStatus(userId, activate) {
    console.log(`${activate ? 'Activating' : 'Deactivating'} user:`, userId);
    
    // API URL
    const apiUrl = `http://localhost:5000/api/admin/users/${userId}/status`;
    
    // Prepare data
    const data = {
        active: activate
    };
    
    // Use jQuery's AJAX to update status
    $.ajax({
        url: apiUrl,
        type: 'PATCH',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json'
        },
        data: JSON.stringify(data),
        success: function(response) {
            showToast('success', 'Success', `User ${activate ? 'activated' : 'deactivated'} successfully`);
            
            // Refresh user list
            loadAdminUsers();
        },
        error: function(xhr, status, error) {
            console.error('Error toggling user status:', error);
            
            if (xhr.status === 0) {
                // API is down, use mock update
                showToast('success', 'Success (Offline)', `User ${activate ? 'activated' : 'deactivated'} successfully`);
                
                // Update UI manually
                const row = $(`#user-list tr[data-user-id="${userId}"]`);
                const statusCell = row.find('td:nth-child(5)');
                const actionButton = row.find('.toggle-status');
                
                if (activate) {
                    statusCell.html('<span class="badge bg-success">Active</span>');
                    actionButton.attr('title', 'Deactivate');
                    actionButton.find('i').removeClass('fa-check').addClass('fa-ban');
                } else {
                    statusCell.html('<span class="badge bg-danger">Inactive</span>');
                    actionButton.attr('title', 'Activate');
                    actionButton.find('i').removeClass('fa-ban').addClass('fa-check');
                }
                
                // Update event listener
                actionButton.off('click').on('click', function() {
                    toggleUserStatus(userId, !activate);
                });
            } else {
                showToast('error', 'Error', `Failed to ${activate ? 'activate' : 'deactivate'} user: ${error}`);
            }
        }
    });
}

// Confirm user deletion
function confirmDeleteUser(userId, userName) {
    // Create modal if it doesn't exist
    if ($('#delete-user-modal').length === 0) {
        const modalHTML = `
            <div class="modal fade" id="delete-user-modal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Delete User</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Are you sure you want to delete this user? This action cannot be undone.</p>
                            <p><strong>User:</strong> <span id="delete-user-name"></span></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-danger" id="confirm-delete-user-btn">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
    }
    
    // Update modal content
    $('#delete-user-name').text(userName);
    
    // Set up delete button
    $('#confirm-delete-user-btn').off('click').on('click', function() {
        deleteUser(userId);
    });
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('delete-user-modal'));
    modal.show();
}

// Delete user
function deleteUser(userId) {
    console.log('Deleting user:', userId);
    
    // API URL
    const apiUrl = `http://localhost:5000/api/admin/users/${userId}`;
    
    // Show loading state
    $('#confirm-delete-user-btn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Deleting...').prop('disabled', true);
    
    // Use jQuery's AJAX to delete user
    $.ajax({
        url: apiUrl,
        type: 'DELETE',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        success: function(response) {
            // Hide modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('delete-user-modal'));
            modal.hide();
            
            showToast('success', 'Success', 'User deleted successfully');
            
            // Refresh user list
            loadAdminUsers();
        },
        error: function(xhr, status, error) {
            console.error('Error deleting user:', error);
            
            if (xhr.status === 0) {
                // API is down, use mock deletion
                const modal = bootstrap.Modal.getInstance(document.getElementById('delete-user-modal'));
                modal.hide();
                
                showToast('success', 'Success (Offline)', 'User deleted successfully');
                
                // Remove row from UI
                $(`#user-list tr[data-user-id="${userId}"]`).fadeOut(300, function() {
                    $(this).remove();
                });
            } else {
                showToast('error', 'Error', `Failed to delete user: ${error}`);
            }
        }
    });
}

// Show add user modal
function showAddUserModal() {
    // Create modal if it doesn't exist
    if ($('#add-user-modal').length === 0) {
        const modalHTML = `
            <div class="modal fade" id="add-user-modal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add New User</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="add-user-form">
                                <div class="mb-3">
                                    <label for="new-user-name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="new-user-name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="new-user-email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="new-user-email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="new-user-password" class="form-label">Password</label>
                                    <input type="password" class="form-control" id="new-user-password" required>
                                </div>
                                <div class="mb-3">
                                    <label for="new-user-role" class="form-label">Role</label>
                                    <select class="form-select" id="new-user-role">
                                        <option value="user">User</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                </div>
                                <div class="alert alert-danger d-none" id="add-user-error"></div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="add-user-submit-btn">Add User</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
        
        // Set up submit button
        $('#add-user-submit-btn').on('click', function() {
            addNewUser();
        });
        
        // Set up form submission
        $('#add-user-form').on('submit', function(e) {
            e.preventDefault();
            addNewUser();
        });
    }
    
    // Clear form
    $('#add-user-form')[0].reset();
    $('#add-user-error').addClass('d-none');
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('add-user-modal'));
    modal.show();
}

// Add new user
function addNewUser() {
    // Get form values
    const name = $('#new-user-name').val().trim();
    const email = $('#new-user-email').val().trim();
    const password = $('#new-user-password').val();
    const role = $('#new-user-role').val();
    
    // Basic validation
    if (!name || !email || !password) {
        $('#add-user-error').removeClass('d-none').text('Name, email, and password are required');
        return;
    }
    
    // Show loading state
    $('#add-user-btn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Adding...').prop('disabled', true);
    $('#add-user-error').addClass('d-none');
    
    // Prepare data
    const userData = {
        name,
        email,
        password,
        role
    };
    
    // API URL
    const apiUrl = 'http://localhost:5000/api/admin/users';
    
    // Use jQuery's AJAX to add user
    $.ajax({
        url: apiUrl,
        type: 'POST',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json'
        },
        data: JSON.stringify(userData),
        success: function(response) {
            // Hide modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('add-user-modal'));
            modal.hide();
            
            showToast('success', 'Success', 'User added successfully');
            
            // Refresh user list
            loadAdminUsers();
        },
        error: function(xhr, status, error) {
            console.error('Error adding user:', error);
            
            if (xhr.status === 409) {
                $('#add-user-error').removeClass('d-none').text('Email already exists');
            } else if (xhr.status === 0) {
                // API is down, use mock addition
                const modal = bootstrap.Modal.getInstance(document.getElementById('add-user-modal'));
                modal.hide();
                
                showToast('success', 'Success (Offline)', 'User added successfully');
                
                // Refresh user list
                loadAdminUsers();
            } else {
                $('#add-user-error').removeClass('d-none').text(`Failed to add user: ${error}`);
            }
        }
    });
}

// Get mock users for testing
function getMockUsers() {
    return [
        {
            id: 1,
            name: 'John Doe',
            email: 'john@example.com',
            role: 'user',
            active: true,
            createdAt: '2023-01-15T10:30:00Z'
        },
        {
            id: 2,
            name: 'Admin User',
            email: 'admin@example.com',
            role: 'admin',
            active: true,
            createdAt: '2023-01-10T08:15:00Z'
        },
        {
            id: 3,
            name: 'Jane Smith',
            email: 'jane@example.com',
            role: 'user',
            active: false,
            createdAt: '2023-02-20T14:45:00Z'
        },
        {
            id: 4,
            name: 'Bob Johnson',
            email: 'bob@example.com',
            role: 'user',
            active: true,
            createdAt: '2023-03-05T11:20:00Z'
        }
    ];
}

// Initialize admin panel when document is ready
$(document).ready(function() {
    console.log('Admin.js document ready handler running');
    
    // Add event listener for refresh users button
    $('#refresh-users-btn').on('click', function() {
        console.log('Refresh users button clicked');
        loadAdminUsers();
    });
}); 