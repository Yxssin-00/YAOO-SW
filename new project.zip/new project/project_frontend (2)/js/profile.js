/**
 * TaskMate - Task Management System
 * Profile Management Functions
 */

console.log('Profile.js loaded successfully!');

// Show profile page
function showProfile() {
    console.log('Showing profile page');
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#profile-link, #sidebar-profile').addClass('active');
    
    // Create profile container if it doesn't exist
    if ($('#profile-container').length === 0) {
        const profileContainer = $(`
            <div id="profile-container">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1><i class="fas fa-user me-2"></i> My Profile</h1>
                    <button class="btn btn-primary" id="edit-profile-btn">
                        <i class="fas fa-edit me-1"></i> Edit Profile
                    </button>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <div class="avatar-placeholder mb-3">
                                    <i class="fas fa-user fa-5x"></i>
                                </div>
                                <h4 id="profile-name"></h4>
                                <p class="text-muted" id="profile-role"></p>
                                <div class="mt-3">
                                    <button class="btn btn-outline-secondary btn-sm" id="change-avatar-btn">
                                        <i class="fas fa-camera me-1"></i> Change Avatar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Profile Information</h5>
                            </div>
                            <div class="card-body">
                                <div id="profile-info">
                                    <!-- Profile info will be loaded here -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mt-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Account Statistics</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4 text-center mb-3">
                                        <h2 id="stats-total-tasks">0</h2>
                                        <p class="text-muted">Total Tasks</p>
                                    </div>
                                    <div class="col-md-4 text-center mb-3">
                                        <h2 id="stats-completed-tasks">0</h2>
                                        <p class="text-muted">Completed</p>
                                    </div>
                                    <div class="col-md-4 text-center mb-3">
                                        <h2 id="stats-pending-tasks">0</h2>
                                        <p class="text-muted">Pending</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);
        
        // Append to main content
        $('#main-content').append(profileContainer);
        
        // Add event listeners
        $('#edit-profile-btn').on('click', showEditProfileModal);
        $('#change-avatar-btn').on('click', function() {
            showToast('info', 'Feature Coming Soon', 'Avatar upload will be available in a future update.');
        });
    }
    
    // Use central container management
    showContainer('profile-container');
    
    // Load profile data
    loadProfileData();
}

// Load profile data
function loadProfileData() {
    if (!currentUser) {
        showToast('error', 'Error', 'User data not available');
        return;
    }
    
    // Update profile info
    $('#profile-name').text(currentUser.name);
    $('#profile-role').text(currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1));
    
    // Update profile details
    const profileInfo = $('#profile-info');
    profileInfo.html(`
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Name</div>
            <div class="col-md-9">${currentUser.name}</div>
        </div>
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Email</div>
            <div class="col-md-9">${currentUser.email}</div>
        </div>
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Role</div>
            <div class="col-md-9">${currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1)}</div>
        </div>
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Account ID</div>
            <div class="col-md-9">${currentUser.id}</div>
        </div>
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Theme</div>
            <div class="col-md-9">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="theme-switch" ${$('body').hasClass('dark-mode') ? 'checked' : ''}>
                    <label class="form-check-label" for="theme-switch">Dark Mode</label>
                </div>
            </div>
        </div>
    `);
    
    // Add event listener for theme switch
    $('#theme-switch').on('change', toggleDarkMode);
    
    // Load user statistics
    loadUserStatistics();
}

// Load user statistics
function loadUserStatistics() {
    // Fetch tasks
    fetchTasks().then(tasks => {
        // Filter user's tasks
        const userTasks = tasks.filter(task => task.userId === currentUser.id);
        
        // Calculate statistics
        const totalTasks = userTasks.length;
        const completedTasks = userTasks.filter(task => task.status === 'completed').length;
        const pendingTasks = totalTasks - completedTasks;
        
        // Update UI
        $('#stats-total-tasks').text(totalTasks);
        $('#stats-completed-tasks').text(completedTasks);
        $('#stats-pending-tasks').text(pendingTasks);
    });
}

// Show edit profile modal
function showEditProfileModal() {
    // Create modal if it doesn't exist
    if ($('#edit-profile-modal').length === 0) {
        const modalHTML = `
            <div class="modal fade" id="edit-profile-modal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Profile</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="edit-profile-form">
                                <div class="mb-3">
                                    <label for="edit-profile-name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="edit-profile-name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="edit-profile-email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="edit-profile-email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="edit-profile-password" class="form-label">New Password (leave blank to keep current)</label>
                                    <input type="password" class="form-control" id="edit-profile-password">
                                </div>
                                <div class="mb-3">
                                    <label for="edit-profile-confirm-password" class="form-label">Confirm New Password</label>
                                    <input type="password" class="form-control" id="edit-profile-confirm-password">
                                </div>
                                <div class="alert alert-danger d-none" id="edit-profile-error"></div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="save-profile-btn">Save Changes</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
        
        // Add event listener for save button
        $('#save-profile-btn').on('click', saveProfileChanges);
    }
    
    // Fill form with current user data
    $('#edit-profile-name').val(currentUser.name);
    $('#edit-profile-email').val(currentUser.email);
    $('#edit-profile-password').val('');
    $('#edit-profile-confirm-password').val('');
    $('#edit-profile-error').addClass('d-none');
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('edit-profile-modal'));
    modal.show();
}

// Save profile changes
function saveProfileChanges() {
    // Get form values
    const name = $('#edit-profile-name').val().trim();
    const email = $('#edit-profile-email').val().trim();
    const password = $('#edit-profile-password').val();
    const confirmPassword = $('#edit-profile-confirm-password').val();
    
    // Basic validation
    if (!name || !email) {
        $('#edit-profile-error').removeClass('d-none').text('Name and email are required');
        return;
    }
    
    if (password && password !== confirmPassword) {
        $('#edit-profile-error').removeClass('d-none').text('Passwords do not match');
        return;
    }
    
    // Prepare update data
    const updateData = {
        name,
        email
    };
    
    if (password) {
        updateData.password = password;
    }
    
    // API URL
    const apiUrl = `http://localhost:5000/api/user/${currentUser.id}`;
    
    // Show loading state
    $('#save-profile-btn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...').prop('disabled', true);
    
    // Use jQuery's AJAX to update profile
    $.ajax({
        url: apiUrl,
        type: 'PUT',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json'
        },
        data: JSON.stringify(updateData),
        success: function(response) {
            // Update current user
            currentUser = response;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            
            // Hide modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('edit-profile-modal'));
            modal.hide();
            
            // Show toast notification
            showToast('success', 'Profile Updated', 'Your profile has been updated successfully');
            
            // Reload profile data
            loadProfileData();
        },
        error: function(xhr, status, error) {
            console.error('Error updating profile:', error);
            
            // Reset button state
            $('#save-profile-btn').html('Save Changes').prop('disabled', false);
            
            if (xhr.status === 0) {
                // API server might be down, use mock update
                console.log('API server might be down, using mock update');
                
                // Update user data locally
                currentUser.name = name;
                currentUser.email = email;
                localStorage.setItem('currentUser', JSON.stringify(currentUser));
                
                // Hide modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('edit-profile-modal'));
                modal.hide();
                
                // Show toast notification
                showToast('success', 'Profile Updated (Offline)', 'Your profile has been updated successfully');
                
                // Reload profile data
                loadProfileData();
            } else if (xhr.status === 409) {
                $('#edit-profile-error').removeClass('d-none').text('Email already in use');
            } else {
                $('#edit-profile-error').removeClass('d-none').text(`Failed to update profile: ${error}`);
            }
        }
    });
}

// Initialize profile when document is ready
$(document).ready(function() {
    console.log('Profile.js document ready handler running');
}); 