/**
 * TaskMate - Task Management System
 * Task Comments Functions
 */

// Global variables for comments
let comments = [];

// Initialize comments system
function initializeComments() {
    // Load comments from localStorage or use empty array
    const savedComments = localStorage.getItem('comments');
    if (savedComments) {
        comments = JSON.parse(savedComments);
    } else {
        // Save empty comments array
        localStorage.setItem('comments', JSON.stringify(comments));
    }
}

// Add comment functionality to task cards
function addCommentFunctionality() {
    // Add comment button to task cards
    $('.task-card').each(function() {
        const taskId = $(this).data('taskId');
        const commentCount = getCommentCount(taskId);
        
        // Add comment button if not already present
        if ($(this).find('.comment-btn').length === 0) {
            const commentBtn = $(`
                <button class="btn btn-sm btn-outline-secondary comment-btn ms-1" data-task-id="${taskId}">
                    <i class="fas fa-comment me-1"></i> Comments (${commentCount})
                </button>
            `);
            
            $(this).find('.btn-group').prepend(commentBtn);
            
            // Attach event listener
            commentBtn.on('click', function() {
                showCommentModal(taskId);
            });
        }
    });
}

// Get comment count for a task
function getCommentCount(taskId) {
    return comments.filter(c => c.taskId === taskId).length;
}

// Show comment modal
function showCommentModal(taskId) {
    // Find task
    const task = tasks.find(t => t.id === taskId);
    
    if (!task) {
        showToast('error', 'Error', 'Task not found');
        return;
    }
    
    // Create modal HTML if it doesn't exist
    if ($('#comment-modal').length === 0) {
        const modalHTML = `
            <div class="modal fade" id="comment-modal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Comments</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="task-info mb-3">
                                <h5 id="comment-task-title"></h5>
                                <p id="comment-task-description" class="text-muted"></p>
                            </div>
                            <hr>
                            <div id="comments-container" class="mb-3">
                                <!-- Comments will be loaded here -->
                            </div>
                            <form id="comment-form">
                                <input type="hidden" id="comment-task-id">
                                <div class="mb-3">
                                    <label for="comment-text" class="form-label">Add a comment</label>
                                    <textarea class="form-control" id="comment-text" rows="2" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Add Comment</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
        
        // Attach event listener to form
        $('#comment-form').on('submit', function(e) {
            e.preventDefault();
            handleAddComment();
        });
    }
    
    // Update modal content
    $('#comment-task-title').text(task.title);
    $('#comment-task-description').text(task.description || 'No description provided.');
    $('#comment-task-id').val(taskId);
    
    // Load comments
    loadComments(taskId);
    
    // Show modal
    const commentModal = new bootstrap.Modal(document.getElementById('comment-modal'));
    commentModal.show();
}

// Load comments for a task
function loadComments(taskId) {
    const container = $('#comments-container');
    container.empty();
    
    // Filter comments for this task
    const taskComments = comments.filter(c => c.taskId === taskId);
    
    if (taskComments.length === 0) {
        container.html('<p class="text-center text-muted">No comments yet. Be the first to comment!</p>');
        return;
    }
    
    // Sort comments by date (newest first)
    taskComments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Render comments
    taskComments.forEach(comment => {
        container.append(createCommentElement(comment));
    });
}

// Create comment element
function createCommentElement(comment) {
    // Format date
    const createdAt = new Date(comment.createdAt);
    const formattedDate = createdAt.toLocaleDateString() + ' ' + createdAt.toLocaleTimeString();
    
    // Create element
    const commentElement = $(`
        <div class="card mb-2">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="card-subtitle text-primary mb-0">${comment.userName}</h6>
                    <small class="text-muted">${formattedDate}</small>
                </div>
                <p class="card-text">${comment.text}</p>
            </div>
        </div>
    `);
    
    return commentElement;
}

// Handle adding a new comment
function handleAddComment() {
    const taskId = $('#comment-task-id').val();
    const commentText = $('#comment-text').val().trim();
    
    // Basic validation
    if (!commentText) {
        showToast('error', 'Error', 'Please enter a comment');
        return;
    }
    
    // Create comment object
    const newComment = {
        id: Date.now().toString(),
        taskId,
        userId: currentUser.id,
        userName: currentUser.name,
        text: commentText,
        createdAt: new Date().toISOString()
    };
    
    // Add to comments array
    comments.push(newComment);
    
    // Save to localStorage
    localStorage.setItem('comments', JSON.stringify(comments));
    
    // Clear form
    $('#comment-text').val('');
    
    // Reload comments
    loadComments(taskId);
    
    // Update comment count on button
    const commentCount = getCommentCount(taskId);
    $(`.comment-btn[data-task-id="${taskId}"]`).html(`
        <i class="fas fa-comment me-1"></i> Comments (${commentCount})
    `);
    
    // Show toast notification
    showToast('success', 'Comment Added', 'Your comment has been added successfully');
}

// Modern task list observer to replace deprecated DOMNodeInserted
function observeTaskList() {
    const taskList = document.getElementById('task-list');
    if (!taskList) return;
    
    // Create a MutationObserver to watch for new task cards
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach(function(node) {
                    if (node.nodeType === Node.ELEMENT_NODE && 
                        (node.classList.contains('task-card') || 
                         node.querySelector && node.querySelector('.task-card'))) {
                        // Add comment functionality to new task cards
                        setTimeout(() => addCommentFunctionality(), 100);
                    }
                });
            }
        });
    });
    
    // Start observing
    observer.observe(taskList, {
        childList: true,
        subtree: true
    });
}

// Initialize comments when document is ready
$(document).ready(function() {
    console.log('Task Comments initialized successfully!');
    initializeComments();
    
    // Set up modern task list observer instead of deprecated DOMNodeInserted
    observeTaskList();
    
    // Also add comment functionality to existing task cards
    setTimeout(() => addCommentFunctionality(), 500);
}); 