/**
 * TaskMate - Task Management System
 * Calendar Functions
 */

console.log('Calendar.js loaded successfully!');

// Show calendar view
function showCalendar() {
    console.log('Showing calendar view');
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#calendar-link, #sidebar-calendar').addClass('active');
    
    // Add event listeners for navigation buttons if not already added
    if (!$('#prev-month-btn').data('events-attached')) {
        $('#prev-month-btn').on('click', function() {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            renderCalendar(currentYear, currentMonth);
        }).data('events-attached', true);
        
        $('#current-month-btn').on('click', function() {
            const today = new Date();
            currentMonth = today.getMonth();
            currentYear = today.getFullYear();
            renderCalendar(currentYear, currentMonth);
        }).data('events-attached', true);
        
        $('#next-month-btn').on('click', function() {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            renderCalendar(currentYear, currentMonth);
        }).data('events-attached', true);
    }
    
    // Use central container management
    showContainer('calendar-container');
    
    // Initialize calendar with current month
    const today = new Date();
    currentMonth = today.getMonth();
    currentYear = today.getFullYear();
    renderCalendar(currentYear, currentMonth);
}

// Global variables for calendar
let currentMonth, currentYear;

// Render calendar for specified month and year
function renderCalendar(year, month) {
    // Update header
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $('#calendar-month-year').text(`${monthNames[month]} ${year}`);
    
    // Get first day of month and number of days
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    // Create calendar grid
    const calendarBody = $('#calendar-body');
    calendarBody.empty();
    
    // Create table
    const table = $('<table class="table table-bordered calendar-table"></table>');
    
    // Create header row with day names
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const headerRow = $('<tr class="calendar-header"></tr>');
    dayNames.forEach(day => {
        headerRow.append(`<th>${day}</th>`);
    });
    table.append(headerRow);
    
    // Create calendar cells
    let date = 1;
    for (let i = 0; i < 6; i++) {
        // Create week row
        const row = $('<tr></tr>');
        
        // Create day cells
        for (let j = 0; j < 7; j++) {
            if (i === 0 && j < firstDay) {
                // Empty cells before first day
                row.append('<td class="calendar-cell empty"></td>');
            } else if (date > daysInMonth) {
                // Empty cells after last day
                row.append('<td class="calendar-cell empty"></td>');
            } else {
                // Regular day cell
                const cellDate = new Date(year, month, date);
                const isToday = isSameDate(cellDate, new Date());
                const cellClass = isToday ? 'calendar-cell today' : 'calendar-cell';
                
                // Create cell with date
                const cell = $(`<td class="${cellClass}">
                    <div class="calendar-date">${date}</div>
                    <div class="calendar-events" data-date="${year}-${String(month + 1).padStart(2, '0')}-${String(date).padStart(2, '0')}"></div>
                </td>`);
                
                row.append(cell);
                date++;
            }
        }
        
        table.append(row);
        
        // Stop if we've used all days
        if (date > daysInMonth) {
            break;
        }
    }
    
    // Add table to calendar
    calendarBody.append(table);
    
    // Load tasks for this month
    loadTasksForCalendar(year, month);
}

// Check if two dates are the same (ignoring time)
function isSameDate(date1, date2) {
    return date1.getDate() === date2.getDate() &&
           date1.getMonth() === date2.getMonth() &&
           date1.getFullYear() === date2.getFullYear();
}

// Load tasks for calendar
function loadTasksForCalendar(year, month) {
    // Get all tasks
    fetchTasks().then(tasks => {
        // Clear existing events
        $('.calendar-events').empty();
        
        // Filter tasks for current month
        const monthStart = new Date(year, month, 1);
        const monthEnd = new Date(year, month + 1, 0);
        
        const monthTasks = tasks.filter(task => {
            const dueDate = new Date(task.dueDate);
            return dueDate >= monthStart && dueDate <= monthEnd;
        });
        
        // Add tasks to calendar
        monthTasks.forEach(task => {
            const dueDate = new Date(task.dueDate);
            const dateString = `${year}-${String(month + 1).padStart(2, '0')}-${String(dueDate.getDate()).padStart(2, '0')}`;
            const eventContainer = $(`.calendar-events[data-date="${dateString}"]`);
            
            if (eventContainer.length) {
                // Create task indicator with color based on priority
                const priorityClass = `priority-${task.priority}`;
                const statusClass = `status-${task.status}`;
                
                const taskElement = $(`
                    <div class="calendar-event ${priorityClass} ${statusClass}" title="${task.title}">
                        <span class="event-title">${task.title}</span>
                    </div>
                `);
                
                // Add click handler to open task details
                taskElement.on('click', function() {
                    openEditTaskModal(task.id);
                });
                
                eventContainer.append(taskElement);
            }
        });
    });
}

// Initialize calendar when document is ready
$(document).ready(function() {
    console.log('Calendar.js document ready handler running');
}); 