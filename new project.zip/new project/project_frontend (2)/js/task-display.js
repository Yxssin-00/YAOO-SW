/**
 * TaskMate - Task Management System
 * Task Display and Manipulation Functions
 */

// Show dashboard page
function showDashboard() {
    if (!currentUser) return;
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#dashboard-link, #sidebar-dashboard').addClass('active');
    
    // Use central container management
    showContainer('dashboard-container');
    
    // Load dashboard data
    loadDashboardData();
}

// Load dashboard data
function loadDashboardData() {
    // Fetch tasks from API
    fetchTasks().then(() => {
        // Update task counts
        const totalCount = tasks.length;
        const inProgressCount = tasks.filter(task => task.status === 'in-progress').length;
        const completedCount = tasks.filter(task => task.status === 'completed').length;
        
        $('#total-tasks-count').text(totalCount);
        $('#in-progress-count').text(inProgressCount);
        $('#completed-count').text(completedCount);
        
        // Display recent tasks (limited to 5)
        const recentTasks = [...tasks].sort((a, b) => {
            return new Date(b.createdAt) - new Date(a.createdAt);
        }).slice(0, 5);
        
        renderRecentTasks(recentTasks);
    }).catch(error => {
        console.log('Dashboard data loading failed, using offline mode');
        // Still try to render with whatever data we have
        renderRecentTasks([]);
    });
}

// Render recent tasks in dashboard
function renderRecentTasks(recentTasks) {
    const container = $('#recent-tasks-container');
    container.empty();
    
    if (recentTasks.length === 0) {
        container.html('<p class="text-center text-muted">No tasks found. Create a new task to get started!</p>');
        return;
    }
    
    recentTasks.forEach(task => {
        container.append(createReadOnlyTaskCard(task));
    });
    
    // Add read-only notice
    container.append(`
        <div class="alert alert-info mt-3">
            <small>This is a read-only view. To manage tasks, go to the <a href="#" class="alert-link" id="goto-my-tasks">My Tasks</a> page.</small>
        </div>
    `);
    
    // Add event listener for the "My Tasks" link
    $('#goto-my-tasks').on('click', showMyTasksWithFilters);
}

// Show My Tasks page
function showMyTasks() {
    if (!currentUser) return;
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#my-tasks-link, #sidebar-my-tasks').addClass('active');
    
    // Use central container management
    showContainer('task-list-container');
    
    // Update heading
    $('#task-list-container h1').text('My Tasks');
    
    // Fetch and display tasks
    fetchTasks().then(() => {
        renderTasks(tasks);
    }).catch(error => {
        console.log('Tasks loading failed, showing empty state');
        renderTasks([]);
    });
}

// Show Shared Tasks page
function showSharedTasks() {
    if (!currentUser) return;
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#shared-tasks-link, #sidebar-shared-tasks').addClass('active');
    
    // Use central container management
    showContainer('task-list-container');
    
    // Update heading
    $('#task-list-container h1').text('Shared Tasks');
    
    // Fetch and display tasks
    fetchTasks().then(() => {
        // Filter shared tasks
        const sharedTasks = tasks.filter(task => task.shared);
        renderTasks(sharedTasks);
    }).catch(error => {
        console.log('Shared tasks loading failed, showing empty state');
        renderTasks([]);
    });
}

// Fetch tasks from API
function fetchTasks() {
    return new Promise((resolve, reject) => {
        // API URL - replace with your actual API endpoint
        const apiUrl = 'http://localhost:5000/api/task';
        
        // Use jQuery's AJAX to fetch tasks
        $.ajax({
            url: apiUrl,
            type: 'GET',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            timeout: 5000, // 5 second timeout
            success: function(response) {
                console.log('Tasks loaded from API successfully');
                tasks = response;
                resolve(tasks);
            },
            error: function(xhr, status, error) {
                console.log('API server unavailable, using offline mode for tasks');
                
                // Fallback to localStorage or sample data if API fails
                const storedTasks = localStorage.getItem('tasks');
                if (storedTasks) {
                    try {
                        tasks = JSON.parse(storedTasks);
                        console.log('Loaded tasks from localStorage:', tasks.length);
                    } catch (e) {
                        console.log('Error parsing stored tasks, using sample data');
                        tasks = getSampleTasks();
                        localStorage.setItem('tasks', JSON.stringify(tasks));
                    }
                } else {
                    console.log('No stored tasks found, generating sample data');
                    tasks = getSampleTasks();
                    localStorage.setItem('tasks', JSON.stringify(tasks));
                }
                
                resolve(tasks);
            }
        });
    });
}

// Generate sample tasks
function getSampleTasks() {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(now.getDate() + 1);
    const nextWeek = new Date(now);
    nextWeek.setDate(now.getDate() + 7);
    
    return [
        {
            id: '1',
            title: 'Complete Project Proposal',
            description: 'Write and submit the project proposal for the new client',
            status: 'in-progress',
            dueDate: tomorrow.toISOString().split('T')[0],
            userId: currentUser.id,
            priority: 'high',
            shared: false,
            tagIds: [1, 4],
            createdAt: now.toISOString()
        },
        {
            id: '2',
            title: 'Review Pull Requests',
            description: 'Review and merge pending pull requests from the team',
            status: 'pending',
            dueDate: nextWeek.toISOString().split('T')[0],
            userId: currentUser.id,
            priority: 'medium',
            shared: true,
            tagIds: [1],
            createdAt: now.toISOString()
        },
        {
            id: '3',
            title: 'Update Documentation',
            description: 'Update the API documentation with new endpoints',
            status: 'completed',
            dueDate: now.toISOString().split('T')[0],
            userId: currentUser.id,
            priority: 'low',
            shared: false,
            tagIds: [1, 4],
            createdAt: now.toISOString()
        }
    ];
}

// Render tasks in the task list
function renderTasks(taskList) {
    const container = $('#task-list');
    container.empty();
    
    if (taskList.length === 0) {
        container.html('<p class="text-center p-5 text-muted">No tasks found. Create a new task to get started!</p>');
        return;
    }
    
    taskList.forEach(task => {
        container.append(createTaskCard(task));
    });
}

// Create a task card
function createTaskCard(task) {
    // Get status class and text
    const statusClass = `status-${task.status}`;
    const statusText = task.status === 'in-progress' ? 'In Progress' : 
                      task.status.charAt(0).toUpperCase() + task.status.slice(1);
    
    // Format date
    const dueDate = new Date(task.dueDate).toLocaleDateString();
    
    // Shared badge if task is shared
    const sharedBadge = task.shared ? 
        `<span class="badge bg-info ms-2" title="This task is shared"><i class="fas fa-share-alt"></i> Shared</span>` : '';
    
    // Create HTML
    const card = $(`
        <div class="card mb-3 task-card priority-${task.priority}" data-task-id="${task.id}">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div>
                        <h5 class="card-title">${task.title} ${sharedBadge}</h5>
                    </div>
                    <span class="badge ${statusClass}">${statusText}</span>
                </div>
                <p class="card-text">${task.description || 'No description provided.'}</p>
                <div class="task-tags mb-3">
                    ${renderTagBadges(task.tagIds)}
                </div>
                
                <!-- Task Comments Section -->
                <div class="task-comments mb-3 d-none">
                    <h6 class="comments-header"><i class="fas fa-comments me-1"></i> Comments</h6>
                    <div class="comments-list"></div>
                    <div class="add-comment-form mt-2">
                        <div class="input-group">
                            <input type="text" class="form-control form-control-sm comment-input" placeholder="Add a comment...">
                            <button class="btn btn-sm btn-primary add-comment-btn" type="button">Add</button>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <small class="text-muted">Due: ${dueDate}</small>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-outline-secondary comment-btn me-1" title="Comments">
                            <i class="fas fa-comment"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-info share-task-btn me-1" title="Share Task">
                            <i class="fas fa-share-alt"></i>
                        </button>
                        <div class="dropdown d-inline-block me-1">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                Status
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item status-change" href="#" data-status="pending">Pending</a></li>
                                <li><a class="dropdown-item status-change" href="#" data-status="in-progress">In Progress</a></li>
                                <li><a class="dropdown-item status-change" href="#" data-status="completed">Completed</a></li>
                            </ul>
                        </div>
                        <button class="btn btn-sm btn-outline-primary edit-task me-1">Edit</button>
                        <button class="btn btn-sm btn-outline-danger delete-task">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    // Attach event listeners
    card.find('.edit-task').on('click', function() {
        openEditTaskModal(task.id);
    });
    
    card.find('.delete-task').on('click', function() {
        openDeleteConfirmation(task.id);
    });
    
    card.find('.status-change').on('click', function(e) {
        e.preventDefault();
        const newStatus = $(this).data('status');
        updateTaskStatus(task.id, newStatus);
    });
    
    card.find('.share-task-btn').on('click', function() {
        openShareTaskModal(task.id);
    });
    
    card.find('.comment-btn').on('click', function() {
        toggleCommentSection(card, task.id);
    });
    
    card.find('.add-comment-btn').on('click', function() {
        const commentText = card.find('.comment-input').val().trim();
        if (commentText) {
            addComment(task.id, commentText, card);
        }
    });
    
    card.find('.comment-input').on('keypress', function(e) {
        if (e.which === 13) { // Enter key
            const commentText = $(this).val().trim();
            if (commentText) {
                addComment(task.id, commentText, card);
            }
            e.preventDefault();
        }
    });
    
    return card;
}

// Create a read-only task card for dashboard
function createReadOnlyTaskCard(task) {
    // Get status class and text
    const statusClass = `status-${task.status}`;
    const statusText = task.status === 'in-progress' ? 'In Progress' : 
                      task.status.charAt(0).toUpperCase() + task.status.slice(1);
    
    // Format date
    const dueDate = new Date(task.dueDate).toLocaleDateString();
    
    // Create HTML
    return $(`
        <div class="card mb-3 task-card priority-${task.priority}">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <h5 class="card-title">${task.title}</h5>
                    <span class="badge ${statusClass}">${statusText}</span>
                </div>
                <p class="card-text">${task.description || 'No description provided.'}</p>
                <div class="task-tags mb-3">
                    ${renderTagBadges(task.tagIds)}
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <small class="text-muted">Due: ${dueDate}</small>
                </div>
            </div>
        </div>
    `);
}

// Render tag badges
function renderTagBadges(tagIds) {
    if (!tagIds || tagIds.length === 0) return '';
    
    return tagIds.map(tagId => {
        const tag = tags.find(t => t.id === tagId);
        if (!tag) return '';
        
        return `<span class="badge rounded-pill me-1" style="background-color: ${tag.color}">${tag.name}</span>`;
    }).join('');
}

// Show new task modal
function showNewTaskModal() {
    // Clear form
    $('#create-task-form')[0].reset();
    $('#task-id').val('');
    
    // Set default date
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0]; // YYYY-MM-DD format
    $('#task-due-date').val(formattedDate);
    
    // Update modal title
    $('#task-modal-title').text('Create New Task');
    
    // Show modal
    const taskModal = new bootstrap.Modal(document.getElementById('task-modal'));
    taskModal.show();
}

// Open edit task modal
function openEditTaskModal(taskId) {
    // Find task
    const task = tasks.find(t => t.id === taskId);
    
    if (!task) {
        showToast('error', 'Error', 'Task not found');
        return;
    }
    
    // Set form values in the edit task modal
    $('#edit-task-id').val(task.id);
    $('#edit-task-title').val(task.title);
    $('#edit-task-description').val(task.description || '');
    $('#edit-task-due-date').val(task.dueDate);
    $('#edit-task-priority').val(task.priority);
    $('#edit-task-status').val(task.status);
    
    // Show edit modal
    const editModal = new bootstrap.Modal(document.getElementById('edit-task-modal'));
    editModal.show();
}

// Open delete confirmation modal
function openDeleteConfirmation(taskId) {
    currentTaskId = taskId;
    const deleteModal = new bootstrap.Modal(document.getElementById('delete-confirm-modal'));
    deleteModal.show();
}

// Handle task form submission
function handleTaskSubmit() {
    // Get form values from the create-task-form
    const taskId = $('#task-id').val();
    const taskData = {
        title: $('#task-title').val(),
        description: $('#task-description').val(),
        dueDate: $('#task-due-date').val(),
        priority: $('#task-priority').val(),
        status: $('#task-status').val()
    };
    
    // Basic validation
    if (!taskData.title || !taskData.dueDate) {
        showToast('error', 'Validation Error', 'Please fill in all required fields');
        return;
    }
    
    // Hide modal
    const taskModal = bootstrap.Modal.getInstance(document.getElementById('task-modal'));
    taskModal.hide();
    
    // Create or update task
    if (taskId) {
        // Update existing task
        updateTask(taskId, taskData).then(updatedTask => {
            // Show toast notification
            showToast('success', 'Task Updated', 'The task has been updated successfully');
            
            // Refresh current view
            refreshTaskView();
        }).catch(error => {
            showToast('error', 'Update Failed', 'Failed to update task: ' + error.message);
        });
    } else {
        // Create new task
        createTask(taskData).then(newTask => {
            // Show toast notification
            showToast('success', 'Task Created', 'The task has been created successfully');
            
            // Refresh current view
            refreshTaskView();
        }).catch(error => {
            showToast('error', 'Creation Failed', 'Failed to create task: ' + error.message);
        });
    }
}

// Helper function to refresh the current task view
function refreshTaskView() {
    if ($('#dashboard-container').is(':visible')) {
        loadDashboardData();
    } else if ($('#task-list-container').is(':visible')) {
        if ($('#shared-tasks-link').hasClass('active')) {
            showSharedTasks();
        } else {
            showMyTasks();
        }
    }
}

// Handle edit task form submission
function handleEditTaskSubmit() {
    // Get form values from the edit-task-form
    const taskId = $('#edit-task-id').val();
    
    if (!taskId) {
        showToast('error', 'Error', 'Task ID not found');
        return;
    }
    
    const taskData = {
        title: $('#edit-task-title').val(),
        description: $('#edit-task-description').val(),
        dueDate: $('#edit-task-due-date').val(),
        priority: $('#edit-task-priority').val(),
        status: $('#edit-task-status').val()
    };
    
    // Basic validation
    if (!taskData.title || !taskData.dueDate) {
        showToast('error', 'Validation Error', 'Please fill in all required fields');
        return;
    }
    
    console.log('Updating task:', taskId, taskData);
    
    // Hide modal
    const editModal = bootstrap.Modal.getInstance(document.getElementById('edit-task-modal'));
    editModal.hide();
    
    // Update task via API
    updateTask(taskId, taskData).then(updatedTask => {
        // Show toast notification
        showToast('success', 'Task Updated', 'The task has been updated successfully');
        
        // Refresh current view
        refreshTaskView();
    }).catch(error => {
        showToast('error', 'Update Failed', 'Failed to update task: ' + error.message);
    });
}

// Create a new task
function createTask(taskData) {
    return new Promise((resolve, reject) => {
        // API URL - updated to match backend routes
        const apiUrl = 'http://localhost:5000/api/tasks';
        
        // Use jQuery's AJAX to create a task
        $.ajax({
            url: apiUrl,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                title: taskData.title,
                description: taskData.description,
                due_date: taskData.dueDate,
                priority: taskData.priority
            }),
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            timeout: 5000, // 5 second timeout
            success: function(response) {
                console.log('Task created successfully:', response);
                
                // Add to tasks array
                tasks.push(response);
                
                // Update localStorage
                localStorage.setItem('tasks', JSON.stringify(tasks));
                
                resolve(response);
            },
            error: function(xhr, status, error) {
                console.log('API server unavailable, using offline mode for task creation');
                
                // Fallback to localStorage if API fails
                const newTask = {
                    ...taskData,
                    id: Date.now().toString(), // Generate a unique ID
                    createdAt: new Date().toISOString(),
                    userId: currentUser.id,
                    shared: false
                };
                
                // Add to tasks array
                tasks.push(newTask);
                
                // Update localStorage
                localStorage.setItem('tasks', JSON.stringify(tasks));
                
                resolve(newTask);
            }
        });
    });
}

// Update an existing task
function updateTask(taskId, taskData) {
    return new Promise((resolve, reject) => {
        // API URL - updated to match backend routes
        const apiUrl = `http://localhost:5000/api/tasks/${taskId}`;
        
        // Use jQuery's AJAX to update a task
        $.ajax({
            url: apiUrl,
            type: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify({
                title: taskData.title,
                description: taskData.description,
                due_date: taskData.dueDate,
                priority: taskData.priority
            }),
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            timeout: 5000, // 5 second timeout
            success: function(response) {
                console.log('Task updated successfully:', response);
                
                // Update tasks array
                const index = tasks.findIndex(task => task.id === taskId);
                if (index !== -1) {
                    tasks[index] = { ...tasks[index], ...response };
                }
                
                // Update localStorage
                localStorage.setItem('tasks', JSON.stringify(tasks));
                
                resolve(response);
            },
            error: function(xhr, status, error) {
                console.log('API server unavailable, using offline mode for task update');
                
                // Fallback to localStorage if API fails
                const index = tasks.findIndex(task => task.id === taskId);
                if (index !== -1) {
                    tasks[index] = { ...tasks[index], ...taskData };
                    
                    // Update localStorage
                    localStorage.setItem('tasks', JSON.stringify(tasks));
                    
                    resolve(tasks[index]);
                } else {
                    reject(new Error('Task not found'));
                }
            }
        });
    });
}

// Update task status
function updateTaskStatus(taskId, newStatus) {
    // API URL - updated to match backend routes
    const apiUrl = `http://localhost:5000/api/tasks/${taskId}/status`;
    
    // Use jQuery's AJAX to update task status
    $.ajax({
        url: apiUrl,
        type: 'PATCH',
        contentType: 'application/json',
        data: JSON.stringify({ status: newStatus }),
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        timeout: 5000, // 5 second timeout
        success: function(response) {
            console.log('Task status updated successfully:', response);
            
            // Update tasks array
            const index = tasks.findIndex(task => task.id === taskId);
            if (index !== -1) {
                tasks[index].status = newStatus;
            }
            
            // Update localStorage
            localStorage.setItem('tasks', JSON.stringify(tasks));
            
            // Update UI
            updateTaskStatusUI(taskId, newStatus);
        },
        error: function(xhr, status, error) {
            console.log('API server unavailable, using offline mode for status update');
            
            // Fallback to localStorage if API fails
            const index = tasks.findIndex(task => task.id === taskId);
            if (index !== -1) {
                tasks[index].status = newStatus;
                
                // Update localStorage
                localStorage.setItem('tasks', JSON.stringify(tasks));
                
                // Update UI
                updateTaskStatusUI(taskId, newStatus);
            }
        }
    });
}

// Helper function to update task status in UI
function updateTaskStatusUI(taskId, newStatus) {
    const taskCard = $(`.task-card[data-task-id="${taskId}"]`);
    const statusBadge = taskCard.find('.badge');
    
    // Remove old status classes
    statusBadge.removeClass('status-pending status-in-progress status-completed');
    
    // Add new status class
    statusBadge.addClass(`status-${newStatus}`);
    
    // Update text
    const statusText = newStatus === 'in-progress' ? 'In Progress' : 
                      newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
    statusBadge.text(statusText);
}

// Delete a task
function handleDeleteTask() {
    const taskId = currentTaskId;
    if (!taskId) return;
    
    // API URL - updated to match backend routes
    const apiUrl = `http://localhost:5000/api/tasks/${taskId}`;
    
    // Show loading state
    $('#confirm-delete-btn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Deleting...').prop('disabled', true);
    
    // Use jQuery's AJAX to delete a task
    $.ajax({
        url: apiUrl,
        type: 'DELETE',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        timeout: 5000, // 5 second timeout
        success: function(response) {
            console.log('Task deleted successfully:', response);
            
            // Complete the deletion process
            completeTaskDeletion(taskId);
        },
        error: function(xhr, status, error) {
            console.log('API server unavailable, using offline mode for task deletion');
            
            // Fallback to localStorage if API fails
            completeTaskDeletion(taskId);
        }
    });
}

// Helper function to complete task deletion process
function completeTaskDeletion(taskId) {
    // Hide modal
    const deleteModal = bootstrap.Modal.getInstance(document.getElementById('delete-confirm-modal'));
    if (deleteModal) {
        deleteModal.hide();
    }
    
    // Remove task card from UI with animation
    const taskCard = $(`.task-card[data-task-id="${taskId}"]`);
    if (taskCard.length) {
        taskCard.fadeOut(300, function() {
            $(this).remove();
            
            // Refresh task counts if on dashboard
            if ($('#dashboard-container').is(':visible')) {
                loadDashboardData();
            }
        });
    }
    
    // Show toast notification
    showToast('success', 'Task Deleted', 'The task has been deleted successfully');
    
    // Reset current task ID
    currentTaskId = null;
} 

// Open share task modal
function openShareTaskModal(taskId) {
    // Find task
    const task = tasks.find(t => t.id === taskId);
    
    if (!task) {
        showToast('error', 'Error', 'Task not found');
        return;
    }
    
    // Set task info in the modal
    $('#share-task-id').val(taskId);
    $('#share-task-title').text(task.title);
    $('#share-task-description').text(task.description || 'No description provided.');
    
    // Clear previous shared users
    $('#shared-users-list').empty();
    $('#share-error').addClass('d-none');
    
    // Add "No users" message
    $('#shared-users-list').append('<p class="text-muted small" id="no-shared-users">No users added yet.</p>');
    
    // Load shared users if any
    if (task.sharedWith && task.sharedWith.length > 0) {
        $('#no-shared-users').remove();
        task.sharedWith.forEach(user => {
            addSharedUserToList(user);
        });
    }
    
    // Clear input field
    $('#share-email').val('');
    
    // Show modal
    const shareModal = new bootstrap.Modal(document.getElementById('share-task-modal'));
    shareModal.show();
}

// Add a user to the shared users list in the modal
function addSharedUserToList(email) {
    // Remove "No users" message if present
    $('#no-shared-users').remove();
    
    // Create user item
    const userItem = $(`
        <div class="shared-user-item" data-email="${email}">
            ${email}
            <span class="shared-user-remove"><i class="fas fa-times"></i></span>
        </div>
    `);
    
    // Add remove functionality
    userItem.find('.shared-user-remove').on('click', function() {
        userItem.remove();
        
        // If no users left, show "No users" message
        if ($('#shared-users-list').children().length === 0) {
            $('#shared-users-list').append('<p class="text-muted small" id="no-shared-users">No users added yet.</p>');
        }
    });
    
    // Add to list
    $('#shared-users-list').append(userItem);
}

// Share task with users
function shareTask(taskId, users) {
    return new Promise((resolve, reject) => {
        // API URL
        const apiUrl = `http://localhost:5000/api/task/${taskId}/share`;
        
        // Use jQuery's AJAX to share task
        $.ajax({
            url: apiUrl,
            type: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            },
            data: JSON.stringify({ users }),
            timeout: 5000,
            success: function(response) {
                console.log('Task shared successfully via API:', response);
                
                // Update task in local array
                const taskIndex = tasks.findIndex(t => t.id === taskId);
                if (taskIndex !== -1) {
                    tasks[taskIndex].shared = true;
                    tasks[taskIndex].sharedWith = users;
                    
                    // Update localStorage
                    localStorage.setItem('tasks', JSON.stringify(tasks));
                    
                    // Update the task card in the UI
                    const taskCard = $(`.task-card[data-task-id="${taskId}"]`);
                    if (taskCard.length) {
                        // Replace the old card with a new one
                        taskCard.replaceWith(createTaskCard(tasks[taskIndex]));
                    }
                }
                resolve(response);
            },
            error: function(xhr, status, error) {
                console.log('API unavailable, sharing task in offline mode');
                
                // Fallback to localStorage if API fails
                const taskIndex = tasks.findIndex(t => t.id === taskId);
                if (taskIndex !== -1) {
                    tasks[taskIndex].shared = true;
                    tasks[taskIndex].sharedWith = users;
                    localStorage.setItem('tasks', JSON.stringify(tasks));
                    
                    // Update the task card in the UI
                    const taskCard = $(`.task-card[data-task-id="${taskId}"]`);
                    if (taskCard.length) {
                        // Replace the old card with a new one
                        taskCard.replaceWith(createTaskCard(tasks[taskIndex]));
                    }
                    
                    resolve({ success: true, message: 'Task shared (offline mode)' });
                } else {
                    reject(new Error('Task not found'));
                }
            }
        });
    });
}

// Toggle comment section visibility
function toggleCommentSection(card, taskId) {
    const commentSection = card.find('.task-comments');
    
    if (commentSection.hasClass('d-none')) {
        // Show comments section
        commentSection.removeClass('d-none');
        
        // Load comments
        loadTaskComments(taskId, card);
    } else {
        // Hide comments section
        commentSection.addClass('d-none');
    }
}

// Load comments for a task
function loadTaskComments(taskId, card) {
    const commentsList = card.find('.comments-list');
    commentsList.empty();
    
    // Show loading indicator
    commentsList.html('<div class="text-center"><div class="spinner-border spinner-border-sm text-primary" role="status"></div></div>');
    
    // API URL
    const apiUrl = `http://localhost:5000/api/task/${taskId}/comments`;
    
    // Use jQuery's AJAX to get comments
    $.ajax({
        url: apiUrl,
        type: 'GET',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        timeout: 5000,
        success: function(response) {
            console.log('Comments loaded successfully:', response);
            renderComments(response, commentsList);
        },
        error: function(xhr, status, error) {
            console.log('API unavailable, loading comments from localStorage');
            
            // Fallback to localStorage if API fails
            const storedComments = localStorage.getItem('comments');
            if (storedComments) {
                try {
                    const allComments = JSON.parse(storedComments);
                    const taskComments = allComments.filter(c => c.taskId === taskId);
                    renderComments(taskComments, commentsList);
                } catch (e) {
                    commentsList.html('<p class="text-muted small">No comments yet.</p>');
                }
            } else {
                commentsList.html('<p class="text-muted small">No comments yet.</p>');
            }
        }
    });
}

// Render comments in the list
function renderComments(comments, container) {
    container.empty();
    
    if (!comments || comments.length === 0) {
        container.html('<p class="text-muted small">No comments yet.</p>');
        return;
    }
    
    // Sort comments by date (newest first)
    comments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Add comments to container
    comments.forEach(comment => {
        const commentDate = new Date(comment.createdAt);
        const formattedDate = commentDate.toLocaleDateString() + ' ' + commentDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        const commentItem = $(`
            <div class="comment-item">
                <div class="d-flex justify-content-between">
                    <span class="comment-author">${comment.userName || 'User'}</span>
                    <span class="comment-time">${formattedDate}</span>
                </div>
                <div class="comment-text">${comment.text}</div>
            </div>
        `);
        
        container.append(commentItem);
    });
}

// Add a comment to a task
function addComment(taskId, commentText, card) {
    // Create comment object
    const comment = {
        taskId,
        text: commentText,
        userId: currentUser.id,
        userName: currentUser.name,
        createdAt: new Date().toISOString()
    };
    
    // Clear input field
    card.find('.comment-input').val('');
    
    // API URL
    const apiUrl = `http://localhost:5000/api/task/${taskId}/comments`;
    
    // Use jQuery's AJAX to add comment
    $.ajax({
        url: apiUrl,
        type: 'POST',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json'
        },
        data: JSON.stringify(comment),
        timeout: 5000,
        success: function(response) {
            console.log('Comment added successfully via API:', response);
            
            // Reload comments
            loadTaskComments(taskId, card);
        },
        error: function(xhr, status, error) {
            console.log('API unavailable, adding comment in offline mode');
            
            // Fallback to localStorage if API fails
            const storedComments = localStorage.getItem('comments');
            let comments = [];
            
            if (storedComments) {
                try {
                    comments = JSON.parse(storedComments);
                } catch (e) {
                    comments = [];
                }
            }
            
            // Add ID to comment
            comment.id = Date.now().toString();
            
            // Add to comments array
            comments.push(comment);
            
            // Save to localStorage
            localStorage.setItem('comments', JSON.stringify(comments));
            
            console.log('Comment added in offline mode:', comment);
            
            // Reload comments
            loadTaskComments(taskId, card);
        }
    });
} 