/**
 * TaskMate - Task Management System
 * jQuery + Bootstrap implementation
 */

// Global variables
let currentUser = null;
let tasks = [];
let tags = [
    { id: 1, name: 'Work', color: '#3B82F6' }, // blue
    { id: 2, name: 'Personal', color: '#10B981' }, // green
    { id: 3, name: 'Urgent', color: '#EF4444' }, // red
    { id: 4, name: 'Learning', color: '#8B5CF6' }, // purple
    { id: 5, name: 'Health', color: '#F59E0B' }, // amber
];
let currentTaskId = null;

// Document Ready Handler
$(document).ready(function() {
    console.log('TaskMate application initializing...');
    
    // Initialize the app
    initializeApp();

    // Attach event listeners
    attachEventListeners();

    // Check authentication on page load
    checkAuthentication();
});

// Initialize the application
function initializeApp() {
    // Set default date for task form
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0]; // YYYY-MM-DD format
    $('#task-due-date').val(formattedDate);

    // Check if dark mode is enabled
    if (localStorage.getItem('darkMode') === 'enabled') {
        $('body').addClass('dark-mode');
        $('#theme-toggle').prop('checked', true);
    }

    // Load tags from localStorage or use defaults
    const savedTags = localStorage.getItem('tags');
    if (savedTags) {
        tags = JSON.parse(savedTags);
    } else {
        // Save default tags
        localStorage.setItem('tags', JSON.stringify(tags));
    }
    
    // Add sample notification test data if no tasks exist
    addSampleNotificationTestData();
    
    console.log('TaskMate application initialized successfully');
}

// Central function to manage container visibility
function showContainer(containerId) {
    console.log('Showing container:', containerId);
    
    // Hide all containers
    $('#dashboard-container').hide();
    $('#task-list-container').hide();
    $('#calendar-container').hide();
    $('#profile-container').hide();
    $('#admin-panel-container').hide();
    
    // Show the requested container
    $(`#${containerId}`).show();
}

// Attach event listeners to elements
function attachEventListeners() {
    // Theme toggle (checkbox)
    $('#theme-toggle').on('change', toggleDarkMode);
    
    // Notification bell
    $('#notification-bell').on('click', function(e) {
        e.preventDefault();
        toggleNotifications();
    });
    
    // Navigation links
    $('#dashboard-link, #sidebar-dashboard').on('click', showDashboard);
    $('#my-tasks-link, #sidebar-my-tasks').on('click', showMyTasksWithFilters);
    $('#shared-tasks-link, #sidebar-shared-tasks').on('click', showSharedTasksWithFilters);
    $('#calendar-link, #sidebar-calendar').on('click', showCalendar);
    
    // Profile link now redirects to profile.html instead of showing profile in main container
    $('#profile-link, #sidebar-profile').on('click', function(e) {
        e.preventDefault();
        window.location.href = './profile.html';
    });
    
    // Debug buttons
    $('button[onclick="console.log(currentUser)"]').off('click').on('click', function() {
        console.log('Current user:', currentUser);
        if (currentUser) {
            showToast('info', 'Current User', `Name: ${currentUser.name}<br>Email: ${currentUser.email}<br>Role: ${currentUser.role}`);
        } else {
            showToast('warning', 'No User', 'No user is currently logged in');
        }
    });
    
    // Authentication - Auth Container
    $('#register-link').on('click', function(e) {
        e.preventDefault();
        showRegisterModal();
    });
    $('#login-link').on('click', function(e) {
        e.preventDefault();
        showLoginModal();
    });
    $('#login-form').on('submit', function(e) {
        e.preventDefault();
        handleLogin();
    });
    $('#login-btn').on('click', handleLogin);
    $('#register-form').on('submit', function(e) {
        e.preventDefault();
        handleRegister();
    });
    $('#register-btn').on('click', handleRegister);
    $('#logout-link').on('click', handleLogout);
    
    // Task operations
    $('#new-task-btn').on('click', showNewTaskModal);
    $('#save-task-btn').on('click', handleTaskSubmit);
    $('#create-task-form').on('submit', function(e) {
        e.preventDefault();
        handleTaskSubmit();
    });
    $('#update-task-btn').on('click', handleEditTaskSubmit);
    $('#edit-task-form').on('submit', function(e) {
        e.preventDefault();
        handleEditTaskSubmit();
    });
    $('#confirm-delete-btn').on('click', handleDeleteTask);
    
    // Share task functionality
    $('#add-share-user').on('click', function() {
        const email = $('#share-email').val().trim();
        if (email) {
            // Check if email is already in the list
            const exists = $('#shared-users-list').find(`[data-email="${email}"]`).length > 0;
            if (exists) {
                $('#share-error').removeClass('d-none').text('This user is already in the list.');
                return;
            }
            
            // Add to list
            addSharedUserToList(email);
            
            // Clear input and error
            $('#share-email').val('');
            $('#share-error').addClass('d-none');
        } else {
            $('#share-error').removeClass('d-none').text('Please enter an email or username.');
        }
    });
    
    $('#share-email').on('keypress', function(e) {
        if (e.which === 13) { // Enter key
            e.preventDefault();
            $('#add-share-user').click();
        }
    });
    
    $('#save-share-btn').on('click', function() {
        const taskId = $('#share-task-id').val();
        
        // Get all emails from the list
        const users = [];
        $('.shared-user-item').each(function() {
            users.push($(this).data('email'));
        });
        
        // Share task
        shareTask(taskId, users)
            .then(response => {
                // Hide modal
                const shareModal = bootstrap.Modal.getInstance(document.getElementById('share-task-modal'));
                shareModal.hide();
                
                // Show toast notification
                showToast('success', 'Task Shared', 'The task has been shared successfully');
            })
            .catch(error => {
                $('#share-error').removeClass('d-none').text(`Failed to share task: ${error.message}`);
            });
    });
}

// Check if user is authenticated
function checkAuthentication() {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('currentUser');
    
    if (!token || !userData) {
        // No token or user data, user is not authenticated
        console.log('No authentication data found, showing login');
        clearAuthData();
        showAuthContainer();
        return;
    }
    
    try {
        // Parse user data
        currentUser = JSON.parse(userData);
        console.log('Found stored user data:', currentUser.name);
        
        // Show authenticated UI immediately to prevent login page flash
        updateAuthenticatedUI();
        
        // Check if we're on the main page or profile page
        if (window.location.pathname.includes('profile.html')) {
            // On profile page - don't show dashboard, profile page handles its own content
            console.log('Profile page detected, skipping dashboard initialization');
        } else {
            // On main page - show app container and dashboard
            showAppContainer();
            showDashboard();
            
            // Initialize notifications after successful authentication
            initializeNotifications();
        }
        
        // For offline mode, skip token verification
        if (navigator.onLine === false) {
            console.log('Offline mode detected, using stored credentials');
            return;
        }
        
        // Try to verify token with API in background (optional, with better error handling)
        verifyToken(token).then(isValid => {
            if (isValid) {
                // Token is valid, no additional action needed as UI is already shown
                console.log('Token verified successfully');
            } else {
                // Token is invalid, clear data and show login
                console.log('Token verification failed - redirecting to login');
                clearAuthData();
                showAuthContainer();
            }
        }).catch(error => {
            // Network error or server down - continue with offline mode
            console.log('API server unavailable, continuing in offline mode with stored credentials');
            // No need to update UI again as it's already been set
        });
    } catch (error) {
        console.error('Error parsing user data:', error);
        // Handle invalid data by clearing it
        clearAuthData();
        showAuthContainer();
    }
}

// Verify token with API
function verifyToken(token) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: 'http://localhost:5000/api/auth/verify',
            type: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            },
            timeout: 5000, // 5 second timeout
            success: function() {
                resolve(true);
            },
            error: function(xhr, status, error) {
                if (xhr.status === 401) {
                    // Token is invalid
                    resolve(false);
                } else {
                    // Network error or server down
                    console.log('API server unavailable for token verification:', error);
                    reject(new Error('Network error'));
                }
            }
        });
    });
}

// Clear all authentication data
function clearAuthData() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    localStorage.removeItem('token');
}

// Show the authentication container
function showAuthContainer() {
    // Check if we're on the profile page
    if (window.location.pathname.includes('profile.html')) {
        // On profile page - redirect to main page for authentication
        console.log('Profile page detected, redirecting to main page for authentication');
        window.location.href = 'index.html';
        return;
    }
    
    // Hide app container, show auth container
    $('#app-container').addClass('d-none');
    $('#auth-container').removeClass('d-none');
    
    // Show login section by default
    $('#login-section').show();
    $('#register-section').hide();
}

// Show the main app container
function showAppContainer() {
    // Hide auth container, show app container
    $('#auth-container').addClass('d-none');
    $('#app-container').removeClass('d-none');
}

// Toggle dark mode
function toggleDarkMode() {
    const isChecked = $('#theme-toggle').prop('checked');
    
    if (isChecked) {
        $('body').addClass('dark-mode');
        localStorage.setItem('darkMode', 'enabled');
    } else {
        $('body').removeClass('dark-mode');
        localStorage.setItem('darkMode', 'disabled');
    }
}

// Update UI for authenticated user
function updateAuthenticatedUI() {
    console.log('Updating UI for authenticated user:', currentUser.name);
    $('#username').text(currentUser.name || 'User');
    
    // Show admin panel link if user is admin
    if (currentUser.role === 'admin') {
        console.log('User has admin privileges');
        
        // Remove existing admin link if any
        $('#sidebar-admin').remove();
        
        // Add admin panel link to sidebar
        $('.sidebar .list-group').append(`
            <a href="#" class="list-group-item list-group-item-action" id="sidebar-admin">
                <i class="fas fa-shield-alt me-2"></i> Admin Panel
            </a>
        `);
        
        // Attach event listener to sidebar link
        $('#sidebar-admin').on('click', function(e) {
            e.preventDefault();
            console.log('Admin panel link clicked');
            showAdminPanel();
        });
        
        // Show admin link in dropdown menu
        $('#admin-link').removeClass('d-none').on('click', function(e) {
            e.preventDefault();
            console.log('Admin dropdown link clicked');
            showAdminPanel();
        });
    } else {
        // Hide admin link for non-admin users
        $('#admin-link').addClass('d-none').off('click');
    }
}

// Show login modal
function showLoginModal() {
    // Show auth container
    showAuthContainer();
    
    // Show login section, hide register section
    $('#login-section').show();
    $('#register-section').hide();
    
    // Focus on email field
    $('#login-email').focus();
}

// Show register modal
function showRegisterModal() {
    // Show auth container
    showAuthContainer();
    
    // Show register section, hide login section
    $('#register-section').show();
    $('#login-section').hide();
    
    // Focus on name field
    $('#register-name').focus();
}

// Handle login form submission
function handleLogin() {
    const email = $('#login-email').val();
    const password = $('#login-password').val();
    
    // Basic validation
    if (!email || !password) {
        $('#login-error').removeClass('d-none').text('Please enter email and password');
        return;
    }
    
    // Show loading state
    $('#login-btn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Logging in...').prop('disabled', true);
    $('#login-error').addClass('d-none');
    
    // Prepare login data
    const loginData = {
        email: email,
        password: password
    };
    
    // Call login API with better error handling
    $.ajax({
        url: 'http://localhost:5000/api/auth/login',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(loginData),
        timeout: 5000, // 5 second timeout
        success: function(response) {
            // Store token in localStorage
            localStorage.setItem('token', response.token);
            
            // Store user data
            currentUser = response.user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            
            // Show app container
            showAppContainer();
            
            // Update UI for authenticated user
            updateAuthenticatedUI();
            
            // Load dashboard
            showDashboard();
            
            // Show toast notification
            showToast('success', 'Login successful!', `Welcome back, ${currentUser.name}`);
        },
        error: function(xhr, status, error) {
            console.log('Login API call failed, trying offline mode');
            
            // Reset button state
            $('#login-btn').html('Login').prop('disabled', false);
            
            if (xhr.status === 401) {
                // Unauthorized - invalid credentials
                $('#login-error').removeClass('d-none').text('Invalid email or password');
            } else {
                // Server unreachable - use mock login for demo
                console.log('Using demo mode with mock credentials');
                $('#login-error').addClass('d-none');
                handleMockLogin(email, password);
            }
        }
    });
}

// Fallback mock login for demo/development
function handleMockLogin(email, password) {
    console.log('Using demo mode authentication');
    
    if (email === 'admin@example.com' && password === 'password') {
        // Admin user
        const mockUser = {
            id: 2,
            name: 'Admin User',
            email: 'admin@example.com',
            role: 'admin'
        };
        
        // Generate a mock token
        const mockToken = btoa(`${email}:${Date.now()}`);
        
        // Store mock data
        localStorage.setItem('token', mockToken);
        currentUser = mockUser;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Show app container
        showAppContainer();
        
        // Update UI and show dashboard
        updateAuthenticatedUI();
        showDashboard();
        showToast('success', 'Login successful (Demo Mode)', `Welcome back, ${currentUser.name}`);
        
    } else if (email === 'john@example.com' && password === 'password') {
        // Regular user
        const mockUser = {
            id: 1,
            name: 'John Doe',
            email: 'john@example.com',
            role: 'user'
        };
        
        // Generate a mock token
        const mockToken = btoa(`${email}:${Date.now()}`);
        
        // Store mock data
        localStorage.setItem('token', mockToken);
        currentUser = mockUser;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Show app container
        showAppContainer();
        
        // Update UI and show dashboard
        updateAuthenticatedUI();
        showDashboard();
        showToast('success', 'Login successful (Demo Mode)', `Welcome back, ${currentUser.name}`);
    } else {
        $('#login-error').removeClass('d-none').text('Demo credentials: john@example.com/password or admin@example.com/password');
        $('#login-btn').html('Login').prop('disabled', false);
    }
}

// Handle registration form submission
function handleRegister() {
    const name = $('#register-name').val();
    const email = $('#register-email').val();
    const password = $('#register-password').val();
    const confirmPassword = $('#register-confirm-password').val();
    
    // Basic validation
    if (!name || !email || !password) {
        $('#register-error').removeClass('d-none').text('Please fill in all fields');
        return;
    }
    
    if (password !== confirmPassword) {
        $('#register-error').removeClass('d-none').text('Passwords do not match');
        return;
    }
    
    // Show loading state
    $('#register-btn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Creating account...').prop('disabled', true);
    $('#register-error').addClass('d-none');
    
    // Prepare registration data
    const registerData = {
        name: name,
        email: email,
        password: password
    };
    
    // Call register API with better error handling
    $.ajax({
        url: 'http://localhost:5000/api/auth/register',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(registerData),
        timeout: 5000,
        success: function(response) {
            // Store token in localStorage
            localStorage.setItem('token', response.token);
            
            // Store user data
            currentUser = response.user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            
            // Show app container
            showAppContainer();
            
            // Update UI for authenticated user
            updateAuthenticatedUI();
            
            // Load dashboard
            showDashboard();
            
            // Show toast notification
            showToast('success', 'Registration successful!', `Welcome, ${name}`);
        },
        error: function(xhr, status, error) {
            console.log('Registration API call failed, using demo mode');
            
            // Reset button state
            $('#register-btn').html('Create Account').prop('disabled', false);
            
            if (xhr.status === 409) {
                // Conflict - email already exists
                $('#register-error').removeClass('d-none').text('Email already exists. Please use a different email.');
            } else {
                // Server unreachable - use mock registration
                console.log('Using demo mode registration');
                $('#register-error').addClass('d-none');
                handleMockRegister(name, email, password);
            }
        }
    });
}

// Fallback mock registration for demo/development
function handleMockRegister(name, email, password) {
    console.log('Using demo mode registration');
    
    // Create a mock user
    const mockUser = {
        id: Date.now(),
        name: name,
        email: email,
        role: 'user'
    };
    
    // Generate a mock token
    const mockToken = btoa(`${email}:${Date.now()}`);
    
    // Store mock data
    localStorage.setItem('token', mockToken);
    currentUser = mockUser;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    // Show app container
    showAppContainer();
    
    // Update UI and show dashboard
    updateAuthenticatedUI();
    showDashboard();
    showToast('success', 'Registration successful (Demo Mode)', `Welcome, ${name}`);
}

// Handle logout
function handleLogout() {
    // Show confirmation if needed
    if (localStorage.getItem('confirmLogout') === 'true') {
        if (!confirm('Are you sure you want to log out?')) {
            return;
        }
    }
    
    // Try to call logout API if needed (with error handling)
    const token = localStorage.getItem('token');
    if (token) {
        $.ajax({
            url: 'http://localhost:5000/api/auth/logout',
            type: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            },
            timeout: 3000,
            complete: function() {
                // Always perform local logout regardless of API success
                performLocalLogout();
            }
        });
    } else {
        performLocalLogout();
    }
}

// Perform local logout actions
function performLocalLogout() {
    // Clear all auth data
    currentUser = null;
    localStorage.removeItem('currentUser');
    localStorage.removeItem('token');
    
    // Stop notification checking
    stopNotificationChecking();
    
    // Hide notifications container
    $('#notifications-container').addClass('d-none');
    
    // Show toast notification
    showToast('info', 'Logged Out', 'You have been logged out successfully');
    
    // Show auth container
    showAuthContainer();
    
    // Reset UI
    $('#username').text('User');
    $('#sidebar-admin').remove();
}

// Utility function to show toast notifications
function showToast(type, title, message) {
    const toastId = 'toast-' + Date.now();
    const bgClass = type === 'success' ? 'bg-success' : 
                    type === 'error' ? 'bg-danger' : 
                    type === 'warning' ? 'bg-warning' : 'bg-info';
    
    const toast = `
        <div class="toast ${bgClass} text-white" role="alert" aria-live="assertive" aria-atomic="true" id="${toastId}">
            <div class="toast-header">
                <strong class="me-auto">${title}</strong>
                <small>just now</small>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `;
    
    $('#toast-container').append(toast);
    const toastElement = document.getElementById(toastId);
    const bsToast = new bootstrap.Toast(toastElement, { autohide: true, delay: 5000 });
    bsToast.show();
    
    // Remove toast from DOM after it's hidden
    $(toastElement).on('hidden.bs.toast', function() {
        $(this).remove();
    });
} 

// Show Admin Panel
function showAdminPanel() {
    console.log('showAdminPanel called, currentUser:', currentUser);
    
    if (!currentUser || currentUser.role !== 'admin') {
        console.log('Access denied: User is not admin');
        showToast('error', 'Access Denied', 'You do not have permission to access the admin panel.');
        return;
    }
    
    console.log('Showing admin panel');
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#sidebar-admin').addClass('active');
    
    // Use central container management
    showContainer('admin-panel-container');
    
    // Check if loadAdminUsers function exists
    if (typeof loadAdminUsers === 'function') {
        console.log('Loading admin users');
        loadAdminUsers();
    } else {
        console.error('loadAdminUsers function not found');
        $('#admin-panel-container').html(`
            <div class="alert alert-danger">
                <h4 class="alert-heading">Error</h4>
                <p>The admin panel functionality could not be loaded. Please check the console for errors.</p>
                <button class="btn btn-primary" onclick="window.location.reload()">Reload Page</button>
            </div>
        `);
    }
}



// ================================
// NOTIFICATION SYSTEM
// ================================

// Global notification variables
let notificationInterval = null;
let dismissedNotifications = new Set();

// Fetch notifications from API or create mock notifications
function fetchNotifications() {
    return new Promise((resolve, reject) => {
        // Check if we're in offline mode or API is known to be unavailable
        const lastApiCheck = localStorage.getItem('lastApiCheck');
        const apiUnavailable = localStorage.getItem('apiUnavailable');
        const now = Date.now();
        
        // If API was checked recently and found unavailable, skip API call for 5 minutes
        if (apiUnavailable === 'true' && lastApiCheck && (now - parseInt(lastApiCheck)) < 5 * 60 * 1000) {
            console.log('API recently unavailable, using mock notifications directly');
            const mockNotifications = generateMockNotifications();
            resolve(mockNotifications);
            return;
        }
        
        const apiUrl = 'http://localhost:5000/api/task/notifications';
        
        $.ajax({
            url: apiUrl,
            type: 'GET',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            timeout: 2000, // Reduced timeout for faster fallback
            success: function(response) {
                // API is working, clear offline flag
                localStorage.removeItem('apiUnavailable');
                localStorage.setItem('lastApiCheck', now.toString());
                resolve(response.notifications || []);
            },
            error: function(xhr, status, error) {
                console.log('API server unavailable, using mock notifications');
                
                // Mark API as unavailable for faster future fallbacks
                localStorage.setItem('apiUnavailable', 'true');
                localStorage.setItem('lastApiCheck', now.toString());
                
                // Create mock notifications based on current data
                const mockNotifications = generateMockNotifications();
                resolve(mockNotifications);
            }
        });
    });
}

// Generate mock notifications for offline mode
function generateMockNotifications() {
    if (!currentUser) return [];
    
    const notifications = [];
    const now = new Date();
    
    // Get tasks from localStorage
    const storedTasks = localStorage.getItem('tasks');
    if (storedTasks) {
        try {
            const tasks = JSON.parse(storedTasks);
            const userTasks = tasks.filter(task => task.userId === currentUser.id);
            
            // Check for tasks due soon (within 24 hours)
            userTasks.forEach(task => {
                if (task.status !== 'completed' && task.dueDate) {
                    const dueDate = new Date(task.dueDate);
                    const timeDiff = dueDate.getTime() - now.getTime();
                    const hoursDiff = timeDiff / (1000 * 60 * 60);
                    
                    if (hoursDiff > 0 && hoursDiff <= 24) {
                        notifications.push({
                            id: `due-${task.id}`,
                            type: 'due_soon',
                            title: 'Task Due Soon',
                            message: `"${task.title}" is due ${hoursDiff < 1 ? 'within an hour' : `in ${Math.round(hoursDiff)} hours`}`,
                            timestamp: now.toISOString(),
                            taskId: task.id,
                            priority: hoursDiff < 1 ? 'urgent' : 'warning'
                        });
                    }
                    
                    // Check for overdue tasks
                    if (hoursDiff < 0) {
                        const daysOverdue = Math.ceil(Math.abs(hoursDiff) / 24);
                        notifications.push({
                            id: `overdue-${task.id}`,
                            type: 'overdue',
                            title: 'Task Overdue',
                            message: `"${task.title}" is ${daysOverdue} day${daysOverdue > 1 ? 's' : ''} overdue`,
                            timestamp: now.toISOString(),
                            taskId: task.id,
                            priority: 'urgent'
                        });
                    }
                }
            });
            
            // Add a sample comment/mention notification
            if (userTasks.length > 0) {
                notifications.push({
                    id: 'comment-sample',
                    type: 'comment',
                    title: 'New Comment',
                    message: 'Someone commented on your task "Project Review"',
                    timestamp: new Date(now.getTime() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
                    taskId: userTasks[0].id,
                    priority: 'info'
                });
            }
        } catch (error) {
            console.error('Error parsing tasks for notifications:', error);
        }
    }
    
    return notifications;
}

// Display notifications in the UI
function displayNotifications(notifications) {
    const notificationsContainer = $('#notifications-container');
    const notificationsList = $('#notifications-list');
    
    // Filter out dismissed notifications
    const activeNotifications = notifications.filter(notification => 
        !dismissedNotifications.has(notification.id)
    );
    
    // Update notification badge
    updateNotificationBadge(activeNotifications.length);
    
    if (activeNotifications.length === 0) {
        notificationsContainer.addClass('d-none');
        return;
    }
    
    // Clear existing notifications
    notificationsList.empty();
    
    // Create notification elements
    activeNotifications.forEach(notification => {
        const alertClass = getAlertClassForPriority(notification.priority);
        const icon = getIconForNotificationType(notification.type);
        const timeAgo = getTimeAgo(notification.timestamp);
        
        const notificationElement = $(`
            <div class="alert ${alertClass} alert-dismissible fade show mb-2" role="alert" data-notification-id="${notification.id}">
                <div class="d-flex align-items-start">
                    <i class="${icon} me-2 mt-1"></i>
                    <div class="flex-grow-1">
                        <strong>${notification.title}</strong>
                        <div class="mt-1">${notification.message}</div>
                        <small class="text-muted d-block mt-1">${timeAgo}</small>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        `);
        
        // Add click handler for task-related notifications
        if (notification.taskId) {
            notificationElement.css('cursor', 'pointer').on('click', function(e) {
                if (!$(e.target).hasClass('btn-close')) {
                    // Navigate to the specific task or open task details
                    showMyTasksWithFilters();
                    // Could add logic here to highlight or focus on the specific task
                }
            });
        }
        
        notificationsList.append(notificationElement);
    });
    
    // Show notifications container
    notificationsContainer.removeClass('d-none');
    
    // Add event listeners for dismissing individual notifications
    notificationsList.find('.alert').on('closed.bs.alert', function() {
        const notificationId = $(this).data('notification-id');
        dismissNotification(notificationId);
    });
}

// Get Bootstrap alert class based on priority
function getAlertClassForPriority(priority) {
    switch (priority) {
        case 'urgent':
            return 'alert-danger';
        case 'warning':
            return 'alert-warning';
        case 'info':
            return 'alert-info';
        default:
            return 'alert-primary';
    }
}

// Get Font Awesome icon based on notification type
function getIconForNotificationType(type) {
    switch (type) {
        case 'due_soon':
            return 'fas fa-clock text-warning';
        case 'overdue':
            return 'fas fa-exclamation-triangle text-danger';
        case 'comment':
            return 'fas fa-comment text-info';
        case 'mention':
            return 'fas fa-at text-primary';
        default:
            return 'fas fa-bell text-primary';
    }
}

// Calculate time ago string
function getTimeAgo(timestamp) {
    const now = new Date();
    const time = new Date(timestamp);
    const diffMs = now.getTime() - time.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
}

// Dismiss a specific notification
function dismissNotification(notificationId) {
    dismissedNotifications.add(notificationId);
    
    // Save dismissed notifications to localStorage
    const dismissed = Array.from(dismissedNotifications);
    localStorage.setItem('dismissedNotifications', JSON.stringify(dismissed));
    
    // If no more active notifications, hide container
    const remainingAlerts = $('#notifications-list .alert:visible');
    if (remainingAlerts.length === 0) {
        $('#notifications-container').addClass('d-none');
    }
}

// Dismiss all notifications
function dismissAllNotifications() {
    $('#notifications-list .alert').each(function() {
        const notificationId = $(this).data('notification-id');
        dismissNotification(notificationId);
        $(this).alert('close');
    });
}

// Load and display notifications
function loadNotifications() {
    if (!currentUser) return;
    
    fetchNotifications()
        .then(notifications => {
            // Cache notifications for immediate display
            cacheNotifications(notifications);
            displayNotifications(notifications);
        })
        .catch(error => {
            console.error('Error loading notifications:', error);
            
            // Fallback to cached notifications if available
            const cachedNotifications = getCachedNotifications();
            if (cachedNotifications.length > 0) {
                displayNotifications(cachedNotifications);
            }
        });
}

// Initialize notification system
function initializeNotifications() {
    console.log('Initializing notification system');
    
    // Load dismissed notifications from localStorage
    const storedDismissed = localStorage.getItem('dismissedNotifications');
    if (storedDismissed) {
        try {
            const dismissed = JSON.parse(storedDismissed);
            dismissedNotifications = new Set(dismissed);
        } catch (error) {
            console.error('Error parsing dismissed notifications:', error);
        }
    }
    
    // Load initial notifications
    loadNotifications();
    
    // Set up periodic checking (every 2 minutes)
    if (notificationInterval) {
        clearInterval(notificationInterval);
    }
    
    notificationInterval = setInterval(() => {
        loadNotifications();
    }, 2 * 60 * 1000); // 2 minutes
    
    // Add event listener for dismiss all button
    $('#dismiss-all-notifications').off('click').on('click', dismissAllNotifications);
}

// Stop notification checking (cleanup)
function stopNotificationChecking() {
    if (notificationInterval) {
        clearInterval(notificationInterval);
        notificationInterval = null;
    }
}

// Update notification badge in navbar
function updateNotificationBadge(count) {
    const badge = $('#notification-badge');
    
    if (count > 0) {
        badge.text(count > 99 ? '99+' : count).removeClass('d-none');
    } else {
        badge.addClass('d-none');
    }
}

// Toggle notifications visibility
function toggleNotifications() {
    const container = $('#notifications-container');
    
    if (container.hasClass('d-none')) {
        // Show container immediately for better UX
        container.removeClass('d-none');
        
        // Check if we have cached notifications to show immediately
        const cachedNotifications = getCachedNotifications();
        if (cachedNotifications.length > 0) {
            displayNotifications(cachedNotifications);
        } else {
            // Show loading state
            $('#notifications-list').html(`
                <div class="alert alert-info mb-2">
                    <div class="d-flex align-items-center">
                        <div class="spinner-border spinner-border-sm me-2" role="status"></div>
                        <span>Loading notifications...</span>
                    </div>
                </div>
            `);
        }
        
        // Load fresh notifications in background
        loadNotifications();
    } else {
        container.addClass('d-none');
    }
}

// Add sample test data for notifications (only if no tasks exist)
function addSampleNotificationTestData() {
    const existingTasks = localStorage.getItem('tasks');
    
    // Only add sample data if no tasks exist
    if (!existingTasks) {
        const now = new Date();
        const dueSoon = new Date(now.getTime() + 2 * 60 * 60 * 1000); // 2 hours from now
        const overdue = new Date(now.getTime() - 24 * 60 * 60 * 1000); // 24 hours ago
        
        const sampleTasks = [
            {
                id: 1,
                title: 'Complete Project Review',
                description: 'Review the quarterly project reports and submit feedback',
                status: 'in-progress',
                priority: 'high',
                dueDate: dueSoon.toISOString().split('T')[0],
                createdAt: new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000).toISOString(),
                userId: 1,
                tags: [1, 3], // Work, Urgent
                assignedTo: null,
                comments: []
            },
            {
                id: 2,
                title: 'Update Documentation',
                description: 'Update the user manual with new features',
                status: 'pending',
                priority: 'medium',
                dueDate: overdue.toISOString().split('T')[0],
                createdAt: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000).toISOString(),
                userId: 1,
                tags: [1], // Work
                assignedTo: null,
                comments: []
            },
            {
                id: 3,
                title: 'Prepare Presentation',
                description: 'Create slides for the monthly team meeting',
                status: 'completed',
                priority: 'low',
                dueDate: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                createdAt: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(),
                userId: 1,
                tags: [1], // Work
                assignedTo: null,
                comments: []
            }
        ];
        
        localStorage.setItem('tasks', JSON.stringify(sampleTasks));
        console.log('Added sample notification test data');
    }
}

// Cache notifications for immediate display
function cacheNotifications(notifications) {
    const cachedData = {
        notifications: notifications,
        timestamp: Date.now()
    };
    localStorage.setItem('cachedNotifications', JSON.stringify(cachedData));
}

// Get cached notifications (valid for 5 minutes)
function getCachedNotifications() {
    try {
        const cached = localStorage.getItem('cachedNotifications');
        if (!cached) return [];
        
        const cachedData = JSON.parse(cached);
        const now = Date.now();
        const fiveMinutes = 5 * 60 * 1000;
        
        // Check if cache is still valid (within 5 minutes)
        if (cachedData.timestamp && (now - cachedData.timestamp) < fiveMinutes) {
            return cachedData.notifications || [];
        }
        
        // Cache is expired, remove it
        localStorage.removeItem('cachedNotifications');
        return [];
    } catch (error) {
        console.error('Error reading cached notifications:', error);
        return [];
    }
} 