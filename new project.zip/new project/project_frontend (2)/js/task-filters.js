/**
 * TaskMate - Task Management System
 * Task Filtering Functions
 */

// Default task filters
const defaultTaskFilters = {
    status: 'all',
    priority: 'all',
    sortBy: 'dueDate',
    sortOrder: 'asc',
    search: '',
    tagIds: [],
    dueDate: 'all' // New due date filter
};

// Current task filters
let taskFilters = { ...defaultTaskFilters };

// Initialize task filters UI
function initializeTaskFilters() {
    // Create filter UI if it doesn't exist
    if ($('.task-filters').children().length === 0) {
        createFilterUI();
    }
    
    // Reset filters to default
    resetFilters();
    
    // Attach event listeners
    attachFilterEventListeners();
}

// Create filter UI elements
function createFilterUI() {
    const filterContainer = $('.task-filters');
    
    // Create filter HTML with enhanced UI
    const filterHTML = `
        <div class="card mb-3">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-filter me-2"></i> Filter & Sort Tasks
                </h5>
                <span class="badge bg-primary">
                    Showing <span id="filtered-task-count">0</span> of <span id="total-task-count">0</span> tasks
                </span>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <!-- Search -->
                    <div class="col-md-4">
                        <label for="task-search" class="form-label">Search</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" id="task-search" placeholder="Search tasks...">
                        </div>
                    </div>
                    
                    <!-- Status filter -->
                    <div class="col-md-4">
                        <label for="status-filter" class="form-label">Status</label>
                        <select class="form-select" id="status-filter">
                            <option value="all">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="in-progress">In Progress</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                    
                    <!-- Priority filter -->
                    <div class="col-md-4">
                        <label for="priority-filter" class="form-label">Priority</label>
                        <select class="form-select" id="priority-filter">
                            <option value="all">All Priority</option>
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                        </select>
                    </div>
                    
                    <!-- Due date filter -->
                    <div class="col-md-4">
                        <label for="due-date-filter" class="form-label">Due Date</label>
                        <select class="form-select" id="due-date-filter">
                            <option value="all">All Due Dates</option>
                            <option value="today">Due Today</option>
                            <option value="tomorrow">Due Tomorrow</option>
                            <option value="week">Due This Week</option>
                            <option value="overdue">Overdue</option>
                        </select>
                    </div>
                    
                    <!-- Sort by -->
                    <div class="col-md-4">
                        <label for="sort-by" class="form-label">Sort By</label>
                        <select class="form-select" id="sort-by">
                            <option value="dueDate">Due Date</option>
                            <option value="priority">Priority</option>
                            <option value="title">Title</option>
                            <option value="status">Status</option>
                        </select>
                    </div>
                    
                    <!-- Sort order -->
                    <div class="col-md-4">
                        <label for="sort-order" class="form-label">Sort Order</label>
                        <select class="form-select" id="sort-order">
                            <option value="asc">Ascending</option>
                            <option value="desc">Descending</option>
                        </select>
                    </div>
                </div>
                
                <!-- Tags -->
                <div class="mt-3">
                    <label class="form-label">Tags</label>
                    <div class="d-flex flex-wrap gap-2" id="tag-filters">
                        <!-- Tag filters will be added here -->
                    </div>
                </div>
                
                <!-- Reset button -->
                <div class="mt-3 text-end">
                    <button class="btn btn-secondary" id="reset-filters">
                        <i class="fas fa-undo me-1"></i> Reset Filters
                    </button>
                </div>

                <!-- Quick filters -->
                <div class="mt-3">
                    <label class="form-label">Quick Filters</label>
                    <div class="d-flex flex-wrap gap-2">
                        <button class="btn btn-sm btn-outline-primary quick-filter" data-filter="today">
                            <i class="fas fa-calendar-day me-1"></i> Due Today
                        </button>
                        <button class="btn btn-sm btn-outline-warning quick-filter" data-filter="overdue">
                            <i class="fas fa-exclamation-circle me-1"></i> Overdue
                        </button>
                        <button class="btn btn-sm btn-outline-danger quick-filter" data-filter="high-priority">
                            <i class="fas fa-arrow-up me-1"></i> High Priority
                        </button>
                        <button class="btn btn-sm btn-outline-success quick-filter" data-filter="completed">
                            <i class="fas fa-check-circle me-1"></i> Completed
                        </button>
                    </div>
                </div>
                
                <!-- Reset button -->
                <div class="mt-3 text-end">
                    <button class="btn btn-secondary" id="reset-filters">
                        <i class="fas fa-undo me-1"></i> Reset Filters
                    </button>
                </div>
            </div>
        </div>
    `;
    
    // Add filter HTML to container
    filterContainer.html(filterHTML);
    
    // Add tag filters
    const tagFiltersContainer = $('#tag-filters .d-flex');
    tags.forEach(tag => {
        const tagButton = $(`
            <button class="btn btn-sm tag-filter" data-tag-id="${tag.id}" style="background-color: ${tag.color}; color: white;">
                ${tag.name}
                <i class="fas fa-check ms-1 d-none"></i>
            </button>
        `);
        tagFiltersContainer.append(tagButton);
    });
}

// Attach event listeners to filter elements
function attachFilterEventListeners() {
    // Search input
    $('#task-search').on('input', function() {
        taskFilters.search = $(this).val().toLowerCase();
        applyFilters();
    });
    
    // Status filter
    $('#status-filter').on('change', function() {
        taskFilters.status = $(this).val();
        applyFilters();
    });
    
    // Priority filter
    $('#priority-filter').on('change', function() {
        taskFilters.priority = $(this).val();
        applyFilters();
    });
    
    // Due date filter
    $('#due-date-filter').on('change', function() {
        taskFilters.dueDate = $(this).val();
        applyFilters();
    });
    
    // Sort by
    $('#sort-by').on('change', function() {
        taskFilters.sortBy = $(this).val();
        applyFilters();
    });
    
    // Sort order
    $('#sort-order').on('change', function() {
        taskFilters.sortOrder = $(this).val();
        applyFilters();
    });
    
    // Tag filters
    $('.tag-filter').on('click', function() {
        const tagId = parseInt($(this).data('tagId'));
        const tagIndex = taskFilters.tagIds.indexOf(tagId);
        
        if (tagIndex === -1) {
            // Add tag to filter
            taskFilters.tagIds.push(tagId);
            $(this).find('.fa-check').removeClass('d-none');
        } else {
            // Remove tag from filter
            taskFilters.tagIds.splice(tagIndex, 1);
            $(this).find('.fa-check').addClass('d-none');
        }
        
        applyFilters();
    });
    
    // Reset filters
    $('#reset-filters').on('click', resetFilters);
    
    // Quick filters
    $('.quick-filter').on('click', function() {
        // Reset filters first
        resetFilters();
        
        // Get filter type
        const filterType = $(this).data('filter');
        
        // Apply the appropriate filter
        switch (filterType) {
            case 'today':
                $('#due-date-filter').val('today').trigger('change');
                break;
            case 'overdue':
                $('#due-date-filter').val('overdue').trigger('change');
                break;
            case 'high-priority':
                $('#priority-filter').val('high').trigger('change');
                break;
            case 'completed':
                $('#status-filter').val('completed').trigger('change');
                break;
        }
        
        // Highlight the active quick filter
        $('.quick-filter').removeClass('active');
        $(this).addClass('active');
    });
}

// Reset filters to default
function resetFilters() {
    // Reset filter object
    taskFilters = { ...defaultTaskFilters };
    
    // Reset UI
    $('#task-search').val('');
    $('#status-filter').val('all');
    $('#priority-filter').val('all');
    $('#due-date-filter').val('all');
    $('#sort-by').val('dueDate');
    $('#sort-order').val('asc');
    $('.tag-filter .fa-check').addClass('d-none');
    
    // Apply filters
    applyFilters();
}

// Apply filters to tasks
function applyFilters() {
    // Start with all tasks
    let currentTasks = [...tasks];
    
    // Filter by status
    if (taskFilters.status !== 'all') {
        currentTasks = currentTasks.filter(task => task.status === taskFilters.status);
    }
    
    // Filter by priority
    if (taskFilters.priority !== 'all') {
        currentTasks = currentTasks.filter(task => task.priority === taskFilters.priority);
    }
    
    // Filter by due date
    if (taskFilters.dueDate !== 'all') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        const nextWeek = new Date(today);
        nextWeek.setDate(nextWeek.getDate() + 7);
        
        currentTasks = currentTasks.filter(task => {
            const dueDate = new Date(task.dueDate);
            dueDate.setHours(0, 0, 0, 0);
            
            switch (taskFilters.dueDate) {
                case 'today':
                    return dueDate.getTime() === today.getTime();
                case 'tomorrow':
                    return dueDate.getTime() === tomorrow.getTime();
                case 'week':
                    return dueDate >= today && dueDate <= nextWeek;
                case 'overdue':
                    return dueDate < today;
                default:
                    return true;
            }
        });
    }
    
    // Filter by tags
    if (taskFilters.tagIds.length > 0) {
        currentTasks = currentTasks.filter(task => {
            if (!task.tagIds) return false;
            return taskFilters.tagIds.some(tagId => task.tagIds.includes(tagId));
        });
    }
    
    // Filter by search term
    if (taskFilters.search) {
        currentTasks = currentTasks.filter(task => {
            return task.title.toLowerCase().includes(taskFilters.search) || 
                   (task.description && task.description.toLowerCase().includes(taskFilters.search));
        });
    }
    
    // Apply sorting
    currentTasks = sortTasks(currentTasks, taskFilters.sortBy, taskFilters.sortOrder);
    
    // Update task count
    $('#filtered-task-count').text(currentTasks.length);
    $('#total-task-count').text(tasks.length);
    
    // Render filtered tasks
    renderTasks(currentTasks);
}

// Sort tasks based on criteria
function sortTasks(taskList, sortBy, sortOrder) {
    return [...taskList].sort((a, b) => {
        let valueA, valueB;
        
        switch(sortBy) {
            case 'dueDate':
                valueA = new Date(a.dueDate);
                valueB = new Date(b.dueDate);
                break;
            case 'priority':
                const priorityValues = { high: 3, medium: 2, low: 1 };
                valueA = priorityValues[a.priority] || 0;
                valueB = priorityValues[b.priority] || 0;
                break;
            case 'title':
                valueA = a.title.toLowerCase();
                valueB = b.title.toLowerCase();
                break;
            case 'status':
                const statusValues = { 'pending': 1, 'in-progress': 2, 'completed': 3 };
                valueA = statusValues[a.status] || 0;
                valueB = statusValues[b.status] || 0;
                break;
            default:
                return 0;
        }
        
        // Compare based on sort order
        if (sortOrder === 'asc') {
            return valueA > valueB ? 1 : valueA < valueB ? -1 : 0;
        } else {
            return valueA < valueB ? 1 : valueA > valueB ? -1 : 0;
        }
    });
}

// Enhanced task rendering for My Tasks view with filters
function showMyTasksWithFilters() {
    // Normal My Tasks logic
    if (!currentUser) return;
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#my-tasks-link, #sidebar-my-tasks').addClass('active');
    
    // Use central container management
    showContainer('task-list-container');
    
    // Update heading
    $('#task-list-container h1').text('My Tasks');
    
    // Initialize filters
    initializeTaskFilters();
    
    // Fetch and display tasks
    fetchTasks().then(() => {
        applyFilters();
    });
}

// Enhanced shared tasks view with filters
function showSharedTasksWithFilters() {
    // Normal Shared Tasks logic
    if (!currentUser) return;
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#shared-tasks-link, #sidebar-shared-tasks').addClass('active');
    
    // Use central container management
    showContainer('task-list-container');
    
    // Update heading
    $('#task-list-container h1').text('Shared Tasks');
    
    // Initialize filters
    initializeTaskFilters();
    
    // Fetch and display shared tasks
    fetchTasks().then(() => {
        applyFilters();
    });
} 